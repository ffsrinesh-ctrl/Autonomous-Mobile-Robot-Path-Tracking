function fig = robot3DBirdEyeDynamic(simOut,xRef,yRef,robotRadius, ...
    obstacleRadius,safeDistance,controllerName,scenarioName)
%ROBOT3DBIRDEYEDYNAMIC Fast static summary of a complete dynamic-obstacle run.
%   This legacy helper intentionally does not animate every logged sample.
%   Use dynamicObstacleDashboard for Play/Pause/Scrub and camera controls.
%   The summary view shows the complete path, the final positions, the
%   closest-approach markers and the whole-run collision result.

if nargin < 7 || isempty(controllerName), controllerName = 'Mobile Robot Controller'; end
if nargin < 8 || isempty(scenarioName), scenarioName = 'Dynamic obstacle'; end
xRef = xRef(:); yRef = yRef(:);
t = squeeze(simOut.tout); t = t(:);
x = requiredSignal(simOut,'robotX');
y = requiredSignal(simOut,'robotY');
psi = requiredSignal(simOut,'robotPsi');
noObstacle = contains(lower(scenarioName),'no obstacle') || contains(lower(scenarioName),'case 1');
if noObstacle
    xObs = nan(size(t)); yObs = nan(size(t)); vxObs = zeros(size(t)); vyObs = zeros(size(t));
else
    xObs = requiredSignal(simOut,'obstacleXLog');
    yObs = requiredSignal(simOut,'obstacleYLog');
    vxObs = optionalSignal(simOut,'obstacleVxLog',numel(t),0);
    vyObs = optionalSignal(simOut,'obstacleVyLog',numel(t),0);
end
vSafe = optionalSignal(simOut,'safeVelocityLog',numel(t),0);
omegaSafe = optionalSignal(simOut,'safeOmegaLog',numel(t),0);
N = min([numel(t),numel(x),numel(y),numel(psi),numel(xObs),numel(yObs), ...
    numel(vxObs),numel(vyObs),numel(vSafe),numel(omegaSafe)]);
t=t(1:N); x=x(1:N); y=y(1:N); psi=psi(1:N);
xObs=xObs(1:N); yObs=yObs(1:N); vxObs=vxObs(1:N); vyObs=vyObs(1:N);
vSafe=vSafe(1:N); omegaSafe=omegaSafe(1:N);
if N < 1, error('No trajectory samples were logged.'); end

goalX=xRef(end); goalY=yRef(end); goalDist=hypot(x-goalX,y-goalY);
goalTolerance=0.10; goalIdx=find(goalDist<=goalTolerance,1,'first'); goalReached=~isempty(goalIdx);
if goalReached, goalTime=t(goalIdx); else, goalTime=NaN; end
if noObstacle
    minCenter=NaN; surfaceGap=NaN; collision=false; thresholdViolated=false;
    kClosest=1; xrClosest=NaN; yrClosest=NaN; xoClosest=NaN; yoClosest=NaN; tClosest=NaN;
else
    [minCenter,kClosest,tau,xrClosest,yrClosest,xoClosest,yoClosest,tClosest] = ...
        closestSweptApproach(t,x,y,xObs,yObs);
    surfaceGap=minCenter-(robotRadius+obstacleRadius);
    collision=minCenter <= robotRadius+obstacleRadius+1e-6;
    thresholdViolated=minCenter < safeDistance;
end

fig=figure('Name',[controllerName ' - ' scenarioName ' (run summary)'], ...
    'Color',[0.98 0.985 0.995],'NumberTitle','off','Position',[60 50 1480 900]);
ax=axes('Parent',fig,'Units','normalized','Position',[0.055 0.16 0.69 0.78]);
hold(ax,'on'); grid(ax,'on'); axis(ax,'equal'); axis(ax,'vis3d');
ax.XColor=[0.12 0.12 0.12]; ax.YColor=[0.12 0.12 0.12]; ax.ZColor=[0.12 0.12 0.12];
ax.GridAlpha=0.18;
xlabel(ax,'X Position (m)','Color',[0.12 0.12 0.12]);
ylabel(ax,'Y Position (m)','Color',[0.12 0.12 0.12]);
zlabel(ax,'Height (m)','Color',[0.12 0.12 0.12]);
if noObstacle
    allX=[xRef;x]; allY=[yRef;y];
else
    allX=[xRef;x;xObs]; allY=[yRef;y;yObs];
end
margin=0.8;
xLimits=[min(allX)-margin,max(allX)+margin]; yLimits=[min(allY)-margin,max(allY)+margin];
if diff(xLimits)<1, xLimits=xLimits+[-0.5 0.5]; end
if diff(yLimits)<1, yLimits=yLimits+[-0.5 0.5]; end
xlim(ax,xLimits); ylim(ax,yLimits); zlim(ax,[0 0.85]);
gx=[xLimits(1) xLimits(2) xLimits(2) xLimits(1)]; gy=[yLimits(1) yLimits(1) yLimits(2) yLimits(2)];
patch(ax,gx,gy,zeros(1,4),[0.90 0.92 0.95],'FaceAlpha',0.48,'EdgeColor','none','HandleVisibility','off');
plot3(ax,xRef,yRef,0.015*ones(size(xRef)),'k--','LineWidth',1.7,'DisplayName','Reference path');
plot3(ax,x,y,0.025*ones(size(x)),'-','Color',[0.08 0.38 0.92],'LineWidth',2.1,'DisplayName','Robot trajectory');
plot3(ax,x(1),y(1),0.04,'s','MarkerSize',8,'MarkerFaceColor',[0.15 0.75 0.22], ...
    'MarkerEdgeColor','k','DisplayName','Robot start');
plot3(ax,goalX,goalY,0.04,'p','MarkerSize',11,'MarkerFaceColor',[1 0.78 0.05], ...
    'MarkerEdgeColor','k','DisplayName','Goal');
if ~noObstacle
    if contains(lower(scenarioName),'static') || max(hypot(vxObs,vyObs)) < 1e-5
        plot3(ax,xObs(end),yObs(end),0.03,'s','MarkerSize',10,'MarkerFaceColor',[0.66 0.24 0.82], ...
            'MarkerEdgeColor','k','DisplayName','Static obstacle');
    else
        plot3(ax,xRef(end:-1:1),yRef(end:-1:1),0.018*ones(size(xRef)),':', ...
            'Color',[0.55 0.18 0.73],'LineWidth',1.2,'DisplayName','Obstacle route (reverse)');
        plot3(ax,xObs,yObs,0.025*ones(size(xObs)),':','Color',[0.63 0.22 0.78], ...
            'LineWidth',1.5,'DisplayName','Obstacle trajectory');
    end
    [Xo,Yo,Zo]=cylinder(obstacleRadius,28); Zo=Zo*0.50;
    surf(ax,Xo+xObs(end),Yo+yObs(end),Zo,'FaceColor',[0.63 0.22 0.78], ...
        'EdgeColor','none','FaceAlpha',0.86,'DisplayName','Obstacle (final position)');
    ang=linspace(0,2*pi,80);
    plot3(ax,xObs(end)+safeDistance*cos(ang),yObs(end)+safeDistance*sin(ang), ...
        0.018*ones(size(ang)),'m--','LineWidth',1.2,'DisplayName','Safety boundary');
    plot3(ax,[x(end) xObs(end)],[y(end) yObs(end)],[0.12 0.22],'-', ...
        'Color',[0.1 0.55 0.18],'LineWidth',1.5,'DisplayName','Final separation');
    plot3(ax,xrClosest,yrClosest,0.045,'p','MarkerSize',11,'MarkerFaceColor',[1 0.45 0.05], ...
        'MarkerEdgeColor','k','DisplayName','Closest approach — robot');
    plot3(ax,xoClosest,yoClosest,0.045,'p','MarkerSize',11,'MarkerFaceColor',[1 0.75 0.05], ...
        'MarkerEdgeColor','k','DisplayName','Closest approach — obstacle');
end
[Xr,Yr,Zr]=cylinder(robotRadius,26); Zr=Zr*0.22;
surf(ax,Xr+x(end),Yr+y(end),Zr,'FaceColor',[0.10 0.42 0.93], ...
    'EdgeColor','none','FaceAlpha',0.98,'DisplayName','Robot (final position)');
headingLength=0.42;
quiver3(ax,x(end),y(end),0.24,headingLength*cos(psi(end)),headingLength*sin(psi(end)),0,0, ...
    'k','LineWidth',1.8,'MaxHeadSize',1.4,'DisplayName','Robot heading');
title(ax,sprintf('%s | %s | final state at t = %.2f s',controllerName,scenarioName,t(end)), ...
    'Interpreter','none','Color',[0.08 0.08 0.08],'FontWeight','bold','FontSize',12);
legend(ax,'Location','southoutside','Orientation','horizontal','NumColumns',3, ...
    'FontSize',8,'TextColor',[0.1 0.1 0.1]);
view(ax,42,28);
try, camlight(ax,'headlight'); lighting(ax,'gouraud'); catch, end

% Persistent whole-run verdict and diagnostics, independent of final frame.
panel=uipanel(fig,'Units','normalized','Position',[0.765 0.58 0.215 0.32], ...
    'Title','WHOLE-RUN RESULT','FontWeight','bold','FontSize',11, ...
    'BackgroundColor',[1 1 1]);
if noObstacle
    status='NO OBSTACLE'; statusColor=[0.05 0.45 0.12];
    details={sprintf('Goal reached: %s',yesNo(goalReached)), ...
        sprintf('Goal time: %s',numberOrNA(goalTime)), ...
        sprintf('Final robot: (%.2f, %.2f) m',x(end),y(end)), ...
        'Collision: not applicable', ...
        'Minimum surface gap: N/A'};
else
    if collision, status='COLLISION DETECTED'; statusColor=[0.78 0.04 0.04];
    else, status='NO COLLISION'; statusColor=[0.03 0.48 0.13]; end
    details={sprintf('Minimum centre distance: %.3f m',minCenter), ...
        sprintf('Minimum surface gap: %.3f m',surfaceGap), ...
        sprintf('Closest approach time: %.2f s',tClosest), ...
        sprintf('Safety threshold violated: %s',yesNo(thresholdViolated)), ...
        sprintf('Goal reached: %s',yesNo(goalReached)), ...
        sprintf('Goal time: %s',numberOrNA(goalTime)), ...
        sprintf('Final robot: (%.2f, %.2f) m',x(end),y(end)), ...
        sprintf('Final safe command: v %.3f m/s, omega %.3f rad/s',vSafe(end),omegaSafe(end))};
end
uicontrol(panel,'Style','text','Units','normalized','Position',[0.04 0.79 0.92 0.15], ...
    'String',status,'FontSize',13,'FontWeight','bold','ForegroundColor',statusColor, ...
    'BackgroundColor',[1 1 1],'HorizontalAlignment','center');
uicontrol(panel,'Style','text','Units','normalized','Position',[0.06 0.06 0.88 0.70], ...
    'String',details,'FontSize',10,'ForegroundColor',[0.12 0.12 0.12], ...
    'BackgroundColor',[1 1 1],'HorizontalAlignment','left');
annotation(fig,'textbox',[0.765 0.31 0.21 0.20],'String', ...
    {'This is a full-run summary, not a time-consuming animation.', ...
     'Use the interactive dashboard for playback, timeline scrubbing and camera presets.'}, ...
    'EdgeColor','none','Color',[0.18 0.18 0.18],'FontSize',10,'FitBoxToText','off');
try, rotate3d(fig,'on'); catch, end
end

function data = requiredSignal(simOut,name)
fields=simOut.who;
if ~any(strcmp(fields,name)), error('Required simulation signal "%s" is missing.',name); end
value=simOut.(name);
if isa(value,'timeseries'), data=value.Data; else, data=value; end
data=squeeze(data); data=data(:);
end

function data = optionalSignal(simOut,name,N,defaultValue)
fields=simOut.who;
if ~any(strcmp(fields,name)), data=defaultValue*ones(N,1); return; end
value=simOut.(name);
if isa(value,'timeseries'), data=value.Data; else, data=value; end
data=squeeze(data); data=data(:);
if isempty(data), data=defaultValue*ones(N,1); elseif numel(data)<N, data=[data;defaultValue*ones(N-numel(data),1)]; end
data=data(1:N);
end

function [bestDist,bestK,bestTau,xr,yr,xo,yo,tClosest] = closestSweptApproach(t,x,y,xObs,yObs)
N=min([numel(t),numel(x),numel(y),numel(xObs),numel(yObs)]);
t=t(1:N); x=x(1:N); y=y(1:N); xObs=xObs(1:N); yObs=yObs(1:N);
if N==1
    bestDist=hypot(xObs(1)-x(1),yObs(1)-y(1)); bestK=1; bestTau=0;
    xr=x(1); yr=y(1); xo=xObs(1); yo=yObs(1); tClosest=t(1); return;
end
bestDist=inf; bestK=1; bestTau=0; xr=x(1);yr=y(1);xo=xObs(1);yo=yObs(1);tClosest=t(1);
for k=1:N-1
    r0=[xObs(k)-x(k);yObs(k)-y(k)];
    r1=[xObs(k+1)-x(k+1);yObs(k+1)-y(k+1)];
    dr=r1-r0; denom=dot(dr,dr);
    if denom>eps, tau=min(1,max(0,-dot(r0,dr)/denom)); else, tau=0; end
    rel=r0+tau*dr; d=hypot(rel(1),rel(2));
    if d<bestDist
        bestDist=d; bestK=k; bestTau=tau;
        xr=x(k)+tau*(x(k+1)-x(k)); yr=y(k)+tau*(y(k+1)-y(k));
        xo=xObs(k)+tau*(xObs(k+1)-xObs(k)); yo=yObs(k)+tau*(yObs(k+1)-yObs(k));
        tClosest=t(k)+tau*(t(k+1)-t(k));
    end
end
end

function s = yesNo(tf)
if tf, s='YES'; else, s='NO'; end
end
function s = numberOrNA(v)
if isfinite(v), s=sprintf('%.2f s',v); else, s='not reached'; end
end
