function fig = dynamicObstacleDashboard(dynamicRunData,xRef,yRef,robotRadius, ...
    obstacleRadius,safeDistance,controllerLabels,scenarioNames,scenarioCaseNumbers)
%DYNAMICOBSTACLEDASHBOARD Interactive, non-blocking browser for all dynamic runs.
%   Opens one GUI for every controller/scenario result. The user chooses a
%   run, plays it quickly, pauses, scrubs backward/forward, and changes the
%   3-D camera view. Whole-run collision status remains visible regardless
%   of the currently displayed frame.
%
%   Collision status uses the closest linearly interpolated relative position
%   between consecutive saved robot/obstacle samples, not just the sampled
%   centres. This is an offline diagnostic estimate, not a formal safety proof.

if nargin < 9
    error('dynamicObstacleDashboard requires all run data and display labels.');
end
xRef = xRef(:); yRef = yRef(:);
if numel(xRef) < 2 || numel(yRef) < 2
    error('Reference path must contain at least two points.');
end

%% Flatten scenario/controller matrix into a simple selector list.
runs = {};
labels = {};
for si = 1:size(dynamicRunData,1)
    for ci = 1:size(dynamicRunData,2)
        d = dynamicRunData{si,ci};
        if isempty(d) || ~isstruct(d), continue; end
        raw = struct(); % clear fields from the previous run before processing this one
        required = {'t','x','y','psi','xObs','yObs'};
        for ri = 1:numel(required)
            if ~isfield(d,required{ri})
                error('Run data is missing field "%s".',required{ri});
            end
        end
        raw.t = d.t(:); raw.x = d.x(:); raw.y = d.y(:); raw.psi = d.psi(:);
        raw.xObs = d.xObs(:); raw.yObs = d.yObs(:);
        raw.vxObs = getVector(d,'vxObs',numel(raw.t),0);
        raw.vyObs = getVector(d,'vyObs',numel(raw.t),0);
        raw.mode = getVector(d,'safetyMode',numel(raw.t),0);
        raw.predicted = getVector(d,'predictedDistance',numel(raw.t),NaN);
        raw.vSafe = getVector(d,'vSafeLog',numel(raw.t),0);
        raw.omegaSafe = getVector(d,'omegaSafeLog',numel(raw.t),0);
        N = min([numel(raw.t),numel(raw.x),numel(raw.y),numel(raw.psi), ...
            numel(raw.xObs),numel(raw.yObs),numel(raw.vxObs),numel(raw.vyObs), ...
            numel(raw.mode),numel(raw.predicted),numel(raw.vSafe),numel(raw.omegaSafe)]);
        names = fieldnames(raw);
        for fi = 1:numel(names)
            temp = raw.(names{fi});
            raw.(names{fi}) = temp(1:N);
        end
        if N < 1, continue; end
        raw.obstacleSpeed = hypot(raw.vxObs,raw.vyObs); % actual speed at each logged instant
        raw.robotSpeed = estimateSpeed(raw.x,raw.y,raw.t);
        raw.scenario = scenarioNames{si};
        raw.controller = controllerLabels{ci};
        raw.caseNo = scenarioCaseNumbers(si);
        raw.obstaclePresent = raw.caseNo ~= 1;
        if isfield(d,'obstaclePresent'), raw.obstaclePresent = logical(d.obstaclePresent); end
        raw.obstacleSpeedNominal = nominalSpeedForCase(raw.caseNo);
        if isfield(d,'obstacleSpeedNominal') && ~isempty(d.obstacleSpeedNominal)
            raw.obstacleSpeedNominal = d.obstacleSpeedNominal;
        end
        raw.goalDistance = hypot(raw.x-xRef(end),raw.y-yRef(end));
        raw.goalReached = any(raw.goalDistance <= 0.10);
        if isfield(d,'goalReached'), raw.goalReached = logical(d.goalReached); end
        raw.goalTime = NaN;
        gi = find(raw.goalDistance <= 0.10,1,'first');
        if ~isempty(gi), raw.goalTime = raw.t(gi); end
        if isfield(d,'goalTime') && isfinite(d.goalTime), raw.goalTime = d.goalTime; end
        if raw.obstaclePresent
            raw.center = hypot(raw.xObs-raw.x,raw.yObs-raw.y);
            raw.surface = raw.center - robotRadius - obstacleRadius;
            [raw.minimumCenter,raw.closestSegmentTime] = sweptMinimum(raw.x,raw.y,raw.xObs,raw.yObs,raw.t);
            raw.minimumSurface = raw.minimumCenter - robotRadius - obstacleRadius;
            raw.collided = raw.minimumCenter <= robotRadius + obstacleRadius + 1e-6;
            raw.thresholdViolated = raw.minimumCenter < safeDistance;
            [~,raw.closestSample] = min(raw.center);

            % The whole-run safety metrics above always use the complete run.
            % For Case 5 / Pure Pursuit only, place the displayed orange and
            % cyan stars at the closest SAME-TIME pair for which both robot
            % and obstacle centres are at X >= 4 m. This is a display-only
            % highlight and does not change collision or safety calculations.
            raw.starRobotXY = [raw.x(raw.closestSample), raw.y(raw.closestSample)];
            raw.starObstacleXY = [raw.xObs(raw.closestSample), raw.yObs(raw.closestSample)];
            raw.starTime = raw.t(raw.closestSample);
            raw.starDistance = raw.center(raw.closestSample);
            isCase5PurePursuit = raw.caseNo == 5 && ...
                contains(lower(char(raw.controller)),'pure pursuit');
            if isCase5PurePursuit
                [starRobotXY,starObstacleXY,starTime,starDistance,foundAfterX4] = ...
                    closestPairAfterX(raw.x,raw.y,raw.xObs,raw.yObs,raw.t,4.0);
                if foundAfterX4
                    raw.starRobotXY = starRobotXY;
                    raw.starObstacleXY = starObstacleXY;
                    raw.starTime = starTime;
                    raw.starDistance = starDistance;
                else
                    warning(['Case 5 Pure Pursuit has no common time where both ', ...
                        'robot and obstacle are at X >= 4 m; displaying the ', ...
                        'closest eligible points on each trajectory separately.']);
                    rIdx = find(raw.x >= 4.0);
                    oIdx = find(raw.xObs >= 4.0);
                    if ~isempty(rIdx)
                        [~,j] = min(raw.x(rIdx)-4.0);
                        raw.starRobotXY = [raw.x(rIdx(j)),raw.y(rIdx(j))];
                    end
                    if ~isempty(oIdx)
                        [~,j] = min(raw.xObs(oIdx)-4.0);
                        raw.starObstacleXY = [raw.xObs(oIdx(j)),raw.yObs(oIdx(j))];
                    end
                    raw.starTime = NaN;
                end
            end
        else
            raw.center = nan(size(raw.x));
            raw.surface = nan(size(raw.x));
            raw.minimumCenter = NaN;
            raw.closestSegmentTime = NaN;
            raw.minimumSurface = NaN;
            raw.collided = false;
            raw.thresholdViolated = false;
            raw.closestSample = 1;
            raw.starRobotXY = [raw.x(1),raw.y(1)];
            raw.starObstacleXY = [raw.xObs(1),raw.yObs(1)];
            raw.starTime = NaN;
            raw.starDistance = NaN;
            raw.predicted(:) = NaN;
        end
        raw.viewIdx = unique(round(linspace(1,N,min(N,500))));
        raw.viewIdx = raw.viewIdx(:)';
        runs{end+1} = raw; %#ok<AGROW>
        if raw.caseNo == 1
            caseDescription = 'NO OBSTACLE';
        elseif raw.caseNo == 2
            caseDescription = 'STATIC OBSTACLE';
        elseif raw.caseNo == 3
            caseDescription = sprintf('SLOWER OBSTACLE %.2f m/s',raw.obstacleSpeedNominal);
        elseif raw.caseNo == 4
            caseDescription = sprintf('EQUAL SPEED %.2f m/s',raw.obstacleSpeedNominal);
        else
            caseDescription = sprintf('FASTER OBSTACLE %.2f m/s',raw.obstacleSpeedNominal);
        end
        labels{end+1} = sprintf('Case %d | %s | %s', ...
            raw.caseNo,raw.controller,caseDescription); %#ok<AGROW>
    end
end
if isempty(runs)
    error('No valid dynamic simulation data was supplied to the dashboard.');
end

%% Figure and layout.
fig = figure('Name','Obstacle Viewer - Cases 1 to 5', ...
    'Color',[0.96 0.97 0.99],'NumberTitle','off', ...
    'Position',[40 35 1480 900],'MenuBar','figure','ToolBar','figure', ...
    'Resize','on');
ax = axes('Parent',fig,'Units','normalized','Position',[0.035 0.205 0.69 0.755]);
hold(ax,'on'); grid(ax,'on'); axis(ax,'equal');

summaryPanel = uipanel(fig,'Units','normalized','Position',[0.745 0.60 0.24 0.36], ...
    'Title','WHOLE-RUN COLLISION RESULT','FontWeight','bold','FontSize',11, ...
    'BackgroundColor',[0.98 0.98 0.99]);
collisionText = uicontrol(summaryPanel,'Style','text','Units','normalized', ...
    'Position',[0.04 0.73 0.92 0.19],'FontSize',15,'FontWeight','bold', ...
    'HorizontalAlignment','center','BackgroundColor',[0.98 0.98 0.99], ...
    'String','CHECKING RUN...');
summaryDetails = uicontrol(summaryPanel,'Style','text','Units','normalized', ...
    'Position',[0.05 0.07 0.90 0.62],'FontSize',10, ...
    'HorizontalAlignment','left','BackgroundColor',[0.98 0.98 0.99], ...
    'String','');

livePanel = uipanel(fig,'Units','normalized','Position',[0.745 0.315 0.24 0.265], ...
    'Title','CURRENT FRAME TELEMETRY','FontWeight','bold','FontSize',10, ...
    'BackgroundColor',[0.98 0.98 0.99]);
liveText = uicontrol(livePanel,'Style','text','Units','normalized', ...
    'Position',[0.05 0.05 0.90 0.90],'FontSize',9.5, ...
    'HorizontalAlignment','left','BackgroundColor',[0.98 0.98 0.99], ...
    'String','');

viewPanel = uipanel(fig,'Units','normalized','Position',[0.745 0.055 0.24 0.24], ...
    'Title','CAMERA VIEWS (mouse-drag to orbit)','FontWeight','bold','FontSize',10, ...
    'BackgroundColor',[0.98 0.98 0.99]);
makeViewButton('ISO',0.03,0.68,@(src,evt)presetView(42,28));
makeViewButton('TOP',0.35,0.68,@(src,evt)presetView(0,90));
makeViewButton('FRONT',0.67,0.68,@(src,evt)presetView(0,0));
makeViewButton('BACK',0.03,0.37,@(src,evt)presetView(180,0));
makeViewButton('LEFT',0.35,0.37,@(src,evt)presetView(90,0));
makeViewButton('RIGHT',0.67,0.37,@(src,evt)presetView(-90,0));
makeViewButton('FIT ALL',0.03,0.06,@(src,evt)fitView());
makeViewButton('ZOOM +',0.35,0.06,@(src,evt)zoomView(0.75));
makeViewButton('ZOOM -',0.67,0.06,@(src,evt)zoomView(1.33));

controlPanel = uipanel(fig,'Units','normalized','Position',[0.035 0.035 0.69 0.145], ...
    'Title','PLAYBACK — animation is paused when the window opens', ...
    'FontWeight','bold','BackgroundColor',[0.98 0.98 0.99]);
runPopup = uicontrol(controlPanel,'Style','popupmenu','Units','normalized', ...
    'Position',[0.012 0.62 0.35 0.29],'String',labels,'Value',1, ...
    'FontSize',9,'Callback',@changeRun);
playButton = uicontrol(controlPanel,'Style','pushbutton','Units','normalized', ...
    'Position',[0.375 0.62 0.095 0.29],'String','PLAY','FontWeight','bold', ...
    'Callback',@playCallback);
pauseButton = uicontrol(controlPanel,'Style','pushbutton','Units','normalized', ...
    'Position',[0.48 0.62 0.095 0.29],'String','PAUSE','Callback',@(src,evt)stopPlayback());
restartButton = uicontrol(controlPanel,'Style','pushbutton','Units','normalized', ...
    'Position',[0.585 0.62 0.11 0.29],'String','RESTART', ...
    'Callback',@restartPlayback);
stepBackButton = uicontrol(controlPanel,'Style','pushbutton','Units','normalized', ...
    'Position',[0.705 0.62 0.075 0.29],'String','STEP -', ...
    'Callback',@(src,evt)stepFrame(-1));
stepFwdButton = uicontrol(controlPanel,'Style','pushbutton','Units','normalized', ...
    'Position',[0.788 0.62 0.075 0.29],'String','STEP +', ...
    'Callback',@(src,evt)stepFrame(1));
speedPopup = uicontrol(controlPanel,'Style','popupmenu','Units','normalized', ...
    'Position',[0.865 0.62 0.123 0.29],'String',{'1x','2x','4x','8x'}, ...
    'Value',3,'FontSize',9,'TooltipString','Playback speed; faster settings skip display frames only.');
frameSlider = uicontrol(controlPanel,'Style','slider','Units','normalized', ...
    'Position',[0.02 0.26 0.96 0.22],'Min',1,'Max',max(2,numel(runs{1}.viewIdx)), ...
    'Value',1,'Callback',@sliderChanged);
timeText = uicontrol(controlPanel,'Style','text','Units','normalized', ...
    'Position',[0.02 0.02 0.96 0.18],'HorizontalAlignment','left', ...
    'BackgroundColor',[0.98 0.98 0.99],'FontSize',9,'String','');

currentRun = 1;
frameIndex = 1;
robotBody = []; headingHandle = []; obstacleBody = []; safeBoundary = [];
robotTrail = []; obstacleTrail = []; separationLine = [];
closestRobotMarker = []; closestObstacleMarker = [];
baseXLim = [0 1]; baseYLim = [0 1];
unitSpeed = [1 2 4 8];
playTimer = timer('ExecutionMode','fixedSpacing','Period',0.03, ...
    'BusyMode','drop','TimerFcn',@timerTick);
set(fig,'CloseRequestFcn',@closeDashboard);

buildScene();
updateWholeRunSummary();
renderFrame();
try, rotate3d(fig,'on'); catch, end

%% Nested callbacks and rendering functions.
    function makeViewButton(label,xp,yp,cb)
        uicontrol(viewPanel,'Style','pushbutton','Units','normalized', ...
            'Position',[xp yp 0.29 0.25],'String',label,'FontSize',9,'Callback',cb);
    end

    function buildScene()
        r = runs{currentRun};
        frameIndex = max(1,min(frameIndex,numel(r.viewIdx)));
        k = r.viewIdx(frameIndex);
        cla(ax); hold(ax,'on'); grid(ax,'on'); axis(ax,'equal');
        xlabel(ax,'X Position (m)'); ylabel(ax,'Y Position (m)'); zlabel(ax,'Height (m)');
        ax.GridAlpha = 0.18;
        margin = 0.8;
        if r.obstaclePresent
            allX = [xRef;r.x;r.xObs];
            allY = [yRef;r.y;r.yObs];
        else
            % Exclude the hidden fixed-port placeholder from all view limits.
            allX = [xRef;r.x];
            allY = [yRef;r.y];
        end
        baseXLim = [min(allX)-margin, max(allX)+margin];
        baseYLim = [min(allY)-margin, max(allY)+margin];
        if diff(baseXLim) < 1, baseXLim = baseXLim + [-0.5 0.5]; end
        if diff(baseYLim) < 1, baseYLim = baseYLim + [-0.5 0.5]; end
        xlim(ax,baseXLim); ylim(ax,baseYLim); zlim(ax,[0 0.8]);
        axis(ax,'vis3d');
        gx = [baseXLim(1) baseXLim(2) baseXLim(2) baseXLim(1)];
        gy = [baseYLim(1) baseYLim(1) baseYLim(2) baseYLim(2)];
        patch(ax,gx,gy,zeros(1,4),[0.92 0.94 0.96], ...
            'FaceAlpha',0.5,'EdgeColor','none','HandleVisibility','off');
        plot3(ax,xRef,yRef,0.015*ones(size(xRef)),'b--','LineWidth',1.8,'DisplayName','Reference path');
        if ~r.obstaclePresent
            text(ax,0.03,0.95,'CASE 1: NO OBSTACLE','Units','normalized', ...
                'FontWeight','bold','Color',[0.05 0.45 0.12]);
        elseif r.caseNo == 2
            plot3(ax,r.xObs(1),r.yObs(1),0.02,'s','MarkerSize',10, ...
                'MarkerFaceColor',[0.63 0.22 0.78],'MarkerEdgeColor','k', ...
                'DisplayName','Static obstacle location');
        else
            plot3(ax,xRef(end:-1:1),yRef(end:-1:1),0.012*ones(size(xRef)), ...
                ':','Color',[0.1 0.58 0.58],'LineWidth',1.2,'DisplayName','Obstacle route (reverse)');
        end
        plot3(ax,xRef(1),yRef(1),0.03,'o','MarkerSize',8,'MarkerFaceColor',[0.2 0.8 0.3], ...
            'MarkerEdgeColor','k','DisplayName','Robot start');
        plot3(ax,xRef(end),yRef(end),0.03,'p','MarkerSize',11,'MarkerFaceColor',[1 0.8 0], ...
            'MarkerEdgeColor','k','DisplayName','Goal');
        [Xr,Yr,Zr] = cylinder(robotRadius,22); Zr = Zr*0.22;
        robotBody = surf(ax,Xr+r.x(k),Yr+r.y(k),Zr, ...
            'FaceColor',[0.12 0.42 0.9],'EdgeColor','none','FaceAlpha',0.96,'DisplayName','Robot');
        if r.obstaclePresent, obstacleVisibility = 'on'; else, obstacleVisibility = 'off'; end
        [Xo,Yo,Zo] = cylinder(obstacleRadius,22); Zo = Zo*0.50;
        obstacleBody = surf(ax,Xo+r.xObs(k),Yo+r.yObs(k),Zo, ...
            'FaceColor',[0.63 0.22 0.78],'EdgeColor','none','FaceAlpha',0.82, ...
            'Visible',obstacleVisibility,'HandleVisibility',obstacleVisibility,'DisplayName','Obstacle');
        headingLength = 0.42;
        headingHandle = quiver3(ax,r.x(k),r.y(k),0.24, ...
            headingLength*cos(r.psi(k)),headingLength*sin(r.psi(k)),0,0, ...
            'k','LineWidth',1.8,'MaxHeadSize',1.4,'DisplayName','Robot heading');
        ang = linspace(0,2*pi,72);
        safeBoundary = plot3(ax,r.xObs(k)+safeDistance*cos(ang), ...
            r.yObs(k)+safeDistance*sin(ang),0.018*ones(size(ang)), ...
            'm--','LineWidth',1.2,'Visible',obstacleVisibility, ...
            'HandleVisibility',obstacleVisibility,'DisplayName','Safety-distance boundary');
        robotTrail = plot3(ax,nan,nan,nan,'Color',[0.12 0.42 0.9], ...
            'LineWidth',2,'DisplayName','Robot trail');
        obstacleTrail = plot3(ax,nan,nan,nan,':','Color',[0.63 0.22 0.78], ...
            'LineWidth',1.5,'Visible',obstacleVisibility,'HandleVisibility',obstacleVisibility, ...
            'DisplayName','Obstacle trail');
        separationLine = plot3(ax,[r.x(k) r.xObs(k)],[r.y(k) r.yObs(k)],[0.12 0.25], ...
            '-','Color',[0.1 0.65 0.15],'LineWidth',1.8, ...
            'Visible',obstacleVisibility,'HandleVisibility',obstacleVisibility, ...
            'DisplayName','Current separation');
        % Use the selected display markers. Case 5 / Pure Pursuit highlights
        % the closest synchronized pair with BOTH X coordinates >= 4 m.
        % Whole-run min-distance and collision metrics remain unfiltered.
        if r.caseNo == 5 && contains(lower(char(r.controller)),'pure pursuit')
            robotStarLabel = 'Case 5 PP highlight (robot, X >= 4 m)';
            obstacleStarLabel = 'Case 5 PP highlight (obstacle, X >= 4 m)';
        else
            robotStarLabel = 'Closest approach (robot)';
            obstacleStarLabel = 'Closest approach (obstacle)';
        end
        closestRobotMarker = plot3(ax,r.starRobotXY(1),r.starRobotXY(2),0.03,'p', ...
            'MarkerSize',10,'MarkerFaceColor',[1 0.45 0.1],'MarkerEdgeColor','k', ...
            'Visible',obstacleVisibility,'HandleVisibility',obstacleVisibility, ...
            'DisplayName',robotStarLabel);
        closestObstacleMarker = plot3(ax,r.starObstacleXY(1),r.starObstacleXY(2),0.03,'p', ...
            'MarkerSize',10,'MarkerFaceColor',[0.0 0.85 1.0],'MarkerEdgeColor','k', ...
            'Visible',obstacleVisibility,'HandleVisibility',obstacleVisibility, ...
            'DisplayName',obstacleStarLabel);
        title(ax,sprintf('Case %d | %s | %s',r.caseNo,r.controller,r.scenario), ...
            'Interpreter','none');
        view(ax,42,28);
        try, camlight(ax,'headlight'); lighting(ax,'gouraud'); catch, end
        legend(ax,'Location','northeast','FontSize',8);
    end

    function renderFrame()
        if ~ishandle(fig), return; end
        r = runs{currentRun};
        nFrames = numel(r.viewIdx);
        frameIndex = max(1,min(nFrames,round(frameIndex)));
        k = r.viewIdx(frameIndex);
        set(frameSlider,'Min',1,'Max',max(2,nFrames),'Value',frameIndex);
        if nFrames > 1
            set(frameSlider,'SliderStep',[1/(nFrames-1), min(10/(nFrames-1),1)]);
        else
            set(frameSlider,'SliderStep',[1 1]);
        end
        % Rebuild the cylinder coordinates for this frame (no cumulative
        % translation, so scrubbing backward is exact).
        % avoid cumulative translation errors as the slider moves.
        [Xr,Yr,Zr] = cylinder(robotRadius,22); Zr = Zr*0.22;
        set(robotBody,'XData',Xr+r.x(k),'YData',Yr+r.y(k),'ZData',Zr);
        [Xo,Yo,Zo] = cylinder(obstacleRadius,22); Zo = Zo*0.50;
        set(obstacleBody,'XData',Xo+r.xObs(k),'YData',Yo+r.yObs(k),'ZData',Zo);
        headingLength = 0.42;
        set(headingHandle,'XData',r.x(k),'YData',r.y(k),'ZData',0.24, ...
            'UData',headingLength*cos(r.psi(k)),'VData',headingLength*sin(r.psi(k)),'WData',0);
        ang = linspace(0,2*pi,72);
        set(safeBoundary,'XData',r.xObs(k)+safeDistance*cos(ang), ...
            'YData',r.yObs(k)+safeDistance*sin(ang));
        pathFrames = r.viewIdx(1:frameIndex);
        set(robotTrail,'XData',r.x(pathFrames),'YData',r.y(pathFrames), ...
            'ZData',0.02*ones(1,numel(pathFrames)));
        set(obstacleTrail,'XData',r.xObs(pathFrames),'YData',r.yObs(pathFrames), ...
            'ZData',0.018*ones(1,numel(pathFrames)));
        modeNames = {'NORMAL TRACKING','STEERING AVOIDANCE','SPEED REDUCTION', ...
            'EMERGENCY BEST-EFFORT','SLOWDOWN + LARGE TURN'};
        modeIdx = min(max(round(r.mode(k)),0),4)+1;
        if r.obstaclePresent
            if r.surface(k) <= 0
                sepColor = [0.85 0.05 0.05];
                contactText = 'CURRENT CONTACT / OVERLAP';
            elseif r.center(k) < safeDistance
                sepColor = [0.95 0.48 0.05];
                contactText = 'INSIDE SAFETY THRESHOLD';
            else
                sepColor = [0.05 0.60 0.16];
                contactText = 'CURRENTLY SEPARATED';
            end
            set(separationLine,'XData',[r.x(k) r.xObs(k)], ...
                'YData',[r.y(k) r.yObs(k)],'ZData',[0.12 0.25],'Color',sepColor);
            obstaclePositionText = sprintf('Obstacle position: (%.2f, %.2f) m',r.xObs(k),r.yObs(k));
            obstacleSpeedText = sprintf('Obstacle speed: current %.3f / configured %.3f m/s', ...
                r.obstacleSpeed(k),r.obstacleSpeedNominal);
            centreText = sprintf('Centre distance: %.3f m',r.center(k));
            surfaceText = sprintf('Instant surface gap: %.3f m',r.surface(k));
            if isfinite(r.predicted(k))
                pred = sprintf('Predicted minimum: %.3f m',r.predicted(k));
            else
                pred = 'Predicted minimum: n/a';
            end
        else
            contactText = 'NO OBSTACLE IN THIS CASE';
            obstaclePositionText = 'Obstacle position: not applicable';
            obstacleSpeedText = 'Obstacle speed: N/A';
            centreText = 'Centre distance: N/A';
            surfaceText = 'Instant surface gap: N/A';
            pred = 'Predicted minimum: N/A';
        end
        liveLines = { ...
            sprintf('Time: %.2f s   (%d/%d display frames)',r.t(k),frameIndex,nFrames), ...
            sprintf('Robot position: (%.2f, %.2f) m',r.x(k),r.y(k)), ...
            obstaclePositionText, ...
            sprintf('Robot speed: %.3f m/s',r.robotSpeed(k)), ...
            obstacleSpeedText, ...
            centreText, ...
            surfaceText, ...
            pred, ...
            sprintf('Safe v / omega: %.3f m/s / %.3f rad/s',r.vSafe(k),r.omegaSafe(k)), ...
            ['Safety mode: ' modeNames{modeIdx}],contactText};
        set(liveText,'String',liveLines);
        set(timeText,'String',sprintf('Displayed time %.2f s of %.2f s. Whole-run result stays visible while you scrub.', ...
            r.t(k),r.t(end)));
        if ~r.obstaclePresent
            set(liveText,'ForegroundColor',[0.05 0.45 0.12]);
        elseif r.surface(k) <= 0
            set(liveText,'ForegroundColor',[0.72 0.02 0.02]);
        elseif r.center(k) < safeDistance
            set(liveText,'ForegroundColor',[0.7 0.35 0.02]);
        else
            set(liveText,'ForegroundColor',[0.08 0.08 0.10]);
        end
        title(ax,sprintf('Case %d | %s | t = %.2f s',r.caseNo,r.controller,r.t(k)), ...
            'Interpreter','none');
        drawnow limitrate;
    end

    function updateWholeRunSummary()
        r = runs{currentRun};
        if ~r.obstaclePresent
            set(collisionText,'String','NO OBSTACLE', ...
                'ForegroundColor',[0.02 0.48 0.12]);
            thresholdText = 'N/A';
            minCentreText = 'Minimum centre distance: N/A';
            minSurfaceText = 'Minimum surface gap: N/A';
            thresholdLabel = 'Safety threshold crossed: N/A';
            approachText = 'Closest approach time: N/A';
        else
            if r.collided
                set(collisionText,'String','COLLISION DETECTED', ...
                    'ForegroundColor',[0.78 0.02 0.02]);
            else
                set(collisionText,'String','NO COLLISION', ...
                    'ForegroundColor',[0.02 0.48 0.12]);
            end
            if r.thresholdViolated, thresholdText = 'YES'; else, thresholdText = 'NO'; end
            minCentreText = sprintf('Minimum centre distance: %.3f m',r.minimumCenter);
            minSurfaceText = sprintf('Minimum surface gap: %.3f m',r.minimumSurface);
            thresholdLabel = sprintf('Safety threshold crossed: %s',thresholdText);
            approachText = sprintf('Closest approach time: %.2f s (approx.)',r.closestSegmentTime);
        end
        if r.goalReached
            if isfinite(r.goalTime), goalText = sprintf('YES (%.2f s)',r.goalTime);
            else, goalText = 'YES'; end
        else
            goalText = 'NO';
        end
        lines = { ...
            sprintf('Run: Case %d | %s',r.caseNo,r.controller), ...
            minCentreText, ...
            minSurfaceText, ...
            sprintf('Hard safety threshold: %.3f m',safeDistance), ...
            thresholdLabel, ...
            sprintf('Goal reached: %s',goalText), ...
            approachText, ...
            'This result covers the FULL run, not just the frame below.'};
        set(summaryDetails,'String',lines);
    end

    function changeRun(~,~)
        stopPlayback();
        currentRun = get(runPopup,'Value');
        frameIndex = 1;
        buildScene();
        updateWholeRunSummary();
        renderFrame();
    end

    function sliderChanged(src,~)
        stopPlayback();
        frameIndex = round(get(src,'Value'));
        renderFrame();
    end

    function playCallback(~,~)
        if ~isvalid(playTimer), return; end
        r = runs{currentRun};
        if frameIndex >= numel(r.viewIdx), frameIndex = 1; renderFrame(); end
        try
            if strcmp(playTimer.Running,'off'), start(playTimer); end
        catch ME
            warning('Could not start playback timer: %s',ME.message);
        end
    end

    function stopPlayback()
        try
            if ~isempty(playTimer) && isvalid(playTimer) && strcmp(playTimer.Running,'on')
                stop(playTimer);
            end
        catch
        end
    end

    function timerTick(~,~)
        if ~ishandle(fig), stopPlayback(); return; end
        r = runs{currentRun};
        increment = unitSpeed(get(speedPopup,'Value'));
        frameIndex = min(numel(r.viewIdx),frameIndex+increment);
        renderFrame();
        if frameIndex >= numel(r.viewIdx), stopPlayback(); end
    end

    function restartPlayback(~,~)
        stopPlayback(); frameIndex = 1; renderFrame();
    end

    function stepFrame(delta)
        stopPlayback();
        frameIndex = frameIndex + delta;
        renderFrame();
    end

    function presetView(az,el)
        view(ax,az,el); drawnow limitrate;
    end

    function fitView()
        xlim(ax,baseXLim); ylim(ax,baseYLim); zlim(ax,[0 0.8]);
        view(ax,42,28); drawnow limitrate;
    end

    function zoomView(factor)
        xl = xlim(ax); yl = ylim(ax);
        xc = mean(xl); yc = mean(yl);
        xhalf = diff(xl)*factor/2; yhalf = diff(yl)*factor/2;
        xlim(ax,[xc-xhalf xc+xhalf]); ylim(ax,[yc-yhalf yc+yhalf]);
        drawnow limitrate;
    end

    function closeDashboard(~,~)
        stopPlayback();
        try, if ~isempty(playTimer) && isvalid(playTimer), delete(playTimer); end, catch, end
        delete(fig);
    end
end

function v = getVector(s,name,n,defaultValue)
if isfield(s,name) && ~isempty(s.(name))
    v = s.(name);
    v = v(:);
else
    v = repmat(defaultValue,n,1);
end
if numel(v) < n
    v(end+1:n,1) = defaultValue;
elseif numel(v) > n
    v = v(1:n);
end
end

function sp = estimateSpeed(x,y,t)
n = min([numel(x),numel(y),numel(t)]);
x=x(1:n); y=y(1:n); t=t(1:n);
if n <= 1, sp = zeros(n,1); return; end
dt = diff(t); dt(dt <= 0) = eps;
sp = [hypot(diff(x),diff(y))./dt; 0];
if n > 1, sp(end) = sp(max(1,end-1)); end
end

function [robotXY,obstacleXY,closestTime,minDistance,found] = closestPairAfterX(x,y,xObs,yObs,t,xLimit)
%CLOSESTPAIRAFTERX Closest synchronized pair while both X coordinates >= xLimit.
% Interpolate within each saved time segment and constrain the segment
% parameter to where BOTH centres satisfy the X-coordinate threshold.
x=x(:); y=y(:); xObs=xObs(:); yObs=yObs(:); t=t(:);
N=min([numel(x),numel(y),numel(xObs),numel(yObs),numel(t)]);
x=x(1:N); y=y(1:N); xObs=xObs(1:N); yObs=yObs(1:N); t=t(1:N);
robotXY=[NaN NaN]; obstacleXY=[NaN NaN]; closestTime=NaN; minDistance=Inf; found=false;
if N < 1, return; end
if N == 1
    if x(1)>=xLimit && xObs(1)>=xLimit
        robotXY=[x(1),y(1)]; obstacleXY=[xObs(1),yObs(1)];
        closestTime=t(1); minDistance=hypot(x(1)-xObs(1),y(1)-yObs(1)); found=true;
    end
    return;
end
for i=1:N-1
    % Intersect [0,1] with robot-X >= xLimit and obstacle-X >= xLimit.
    lo=0; hi=1; valid=true;
    ends=[x(i),x(i+1); xObs(i),xObs(i+1)];
    for q=1:2
        a0=ends(q,1); a1=ends(q,2);
        if a0 < xLimit && a1 < xLimit
            valid=false; break;
        elseif a0 < xLimit && a1 >= xLimit
            if abs(a1-a0)<eps, valid=false; break; end
            lo=max(lo,(xLimit-a0)/(a1-a0));
        elseif a0 >= xLimit && a1 < xLimit
            if abs(a1-a0)<eps, valid=false; break; end
            hi=min(hi,(xLimit-a0)/(a1-a0));
        end
    end
    if ~valid || lo > hi, continue; end
    r0=[x(i)-xObs(i), y(i)-yObs(i)];
    r1=[x(i+1)-xObs(i+1), y(i+1)-yObs(i+1)];
    dr=r1-r0; den=dot(dr,dr);
    if den>eps, aStar=-dot(r0,dr)/den; else, aStar=lo; end
    alpha=min(max(aStar,lo),hi);
    rx=x(i)+alpha*(x(i+1)-x(i));
    ry=y(i)+alpha*(y(i+1)-y(i));
    ox=xObs(i)+alpha*(xObs(i+1)-xObs(i));
    oy=yObs(i)+alpha*(yObs(i+1)-yObs(i));
    d=hypot(rx-ox,ry-oy);
    if d < minDistance
        minDistance=d;
        robotXY=[rx,ry]; obstacleXY=[ox,oy];
        closestTime=t(i)+alpha*(t(i+1)-t(i));
        found=true;
    end
end
end

function [minDistance,minTime] = sweptMinimum(x,y,xObs,yObs,t)
% Closest relative separation along every line segment between saved samples.
rX = x(:)-xObs(:); rY = y(:)-yObs(:); t=t(:);
N = min([numel(rX),numel(rY),numel(t)]);
rX=rX(1:N); rY=rY(1:N); t=t(1:N);
pointDist = hypot(rX,rY);
[minDistance,idx] = min(pointDist); minTime=t(idx);
if N < 2, return; end
dX=diff(rX); dY=diff(rY); den=dX.^2+dY.^2;
alpha=zeros(N-1,1); valid=den>eps;
q=find(valid);
alpha(q)=-(rX(q).*dX(q)+rY(q).*dY(q))./den(q);
alpha=min(max(alpha,0),1);
segDist=hypot(rX(1:end-1)+alpha.*dX,rY(1:end-1)+alpha.*dY);
[segMin,segIdx]=min(segDist);
if segMin < minDistance
    minDistance=segMin;
    minTime=t(segIdx)+alpha(segIdx)*(t(segIdx+1)-t(segIdx));
end
end

function v = nominalSpeedForCase(caseNo)
switch caseNo
    case 1, v = NaN;  % no obstacle
    case 2, v = 0.00; % static obstacle
    case 3, v = 0.10; % slower than robot
    case 4, v = 0.22; % equal speed to default robot speed
    case 5, v = 0.30; % faster than robot
    otherwise, v = NaN;
end
end
