function open_dynamic_obstacle_viewer()
% OPEN_DYNAMIC_OBSTACLE_VIEWER Reopen V17 playback without rerunning Simulink.
% Run master_run_project_dynamic_obstacle_v17 once to create fresh V17 viewer data.

projectDirectory = fileparts(mfilename('fullpath'));
if isempty(projectDirectory), projectDirectory = pwd; end
if isfolder(projectDirectory) && ~strcmpi(pwd,projectDirectory), cd(projectDirectory); end

resultsFolder = fullfile(projectDirectory,'project_results');
viewerFile = fullfile(resultsFolder,'dynamic_obstacle_viewer_data.mat');
if ~isfile(viewerFile)
    error(['Saved viewer data was not found: %s\n', ...
        'Run master_run_project_dynamic_obstacle_v17 once first.'],viewerFile);
end
if exist('dynamicObstacleDashboard','file') ~= 2
    error('dynamicObstacleDashboard.m must be in the project folder or on the MATLAB path.');
end

S = load(viewerFile,'viewerDataVersion','dynamicViewerRunData','xRef','yRef', ...
    'robotRadius','obstacleRadius','safeDistance','scenarioNames', ...
    'scenarioCaseNumbers','controllerLabels');
if ~isfield(S,'viewerDataVersion') || S.viewerDataVersion ~= 17
    error(['Saved viewer data is not from V17. Run ', ...
        'master_run_project_dynamic_obstacle_v17 first to regenerate it with the Case 2 local prediction horizon.']);
end
required = {'dynamicViewerRunData','xRef','yRef','robotRadius','obstacleRadius', ...
    'safeDistance','scenarioNames','scenarioCaseNumbers','controllerLabels'};
for k = 1:numel(required)
    if ~isfield(S,required{k})
        error('Saved viewer file is missing variable "%s".',required{k});
    end
end

fprintf('Opening saved V17 obstacle viewer. Simulink will NOT be run again.\n');
summaryFile = fullfile(resultsFolder,'dynamic_obstacle_collision_summary.csv');
if isfile(summaryFile)
    fprintf('\nSaved collision summary:\n');
    disp(readtable(summaryFile));
end

dynamicObstacleDashboard(S.dynamicViewerRunData,S.xRef,S.yRef, ...
    S.robotRadius,S.obstacleRadius,S.safeDistance, ...
    S.controllerLabels,S.scenarioNames,S.scenarioCaseNumbers);
end
