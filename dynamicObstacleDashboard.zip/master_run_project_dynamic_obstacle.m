

clear;
clc;
close all;


projectDirectory = fileparts(mfilename('fullpath'));
if isempty(projectDirectory)
    projectDirectory = pwd;
end
if isfolder(projectDirectory) && ~strcmpi(pwd,projectDirectory)
    cd(projectDirectory);
end

fprintf('\n');
fprintf('============================================================\n');
fprintf(' AUTONOMOUS MOBILE ROBOT PATH TRACKING\n');
fprintf(' PURE PURSUIT AND STANLEY CONTROLLERS\n');
fprintf('============================================================\n');
fprintf(' V17: GENTLE OBSTACLE-APPROACH SLOWDOWN + INTERACTIVE DASHBOARD\n');
fprintf(' CASES 1-5: NO OBSTACLE, STATIC, SLOWER, EQUAL, FASTER\n');
fprintf('============================================================\n');



outputFolder = 'project_results';

if ~exist(outputFolder,'dir')
    mkdir(outputFolder);
end

RUN_3D = true;

% Reference-path timing
Ts = 30;

% Differential-drive robot
wheelRadius = 0.033;
trackWidth = 0.16;
robotRadius = 0.105;

% Pure Pursuit
v_const = 0.22;
ld = 0.35;
omega_max = 2.84;

% Initial robot state
psi_o = 0;

% Stanley
stanleyGain = 0.80;
stanleyLength = 0.35;

% Baseline obstacle: outside the reference-path area
baselineObstacleX = -8.5;
baselineObstacleY = 1.0;

% Obstacle experiment: static obstacle location for Case 2
staticObstacleX = 6.0;
staticObstacleY = 0.45;
obstacleRadius = 0.15;  % obstacle physical radius (m)
safeDistance = 0.35;     % hard minimum centre-to-centre distance (m)
planningBuffer = 0.12;   % preferred extra centre-distance buffer (m)

%% ==============================================================
% LOAD REFERENCE DATASET
% ==============================================================

fprintf('\n============================================================\n');
fprintf(' STEP 1 - REFERENCE PATH DATASET\n');
fprintf('============================================================\n');


referencePathFile = fullfile(projectDirectory,'reference_path.csv');
if ~isfile(referencePathFile)
    error(['Missing %s. Copy reference_path_v17.csv next to this script. ', ...
        'The project uses the same verified path for all five cases.'],referencePathFile);
end
pathTable = readtable(referencePathFile,'VariableNamingRule','preserve');
variableNames = pathTable.Properties.VariableNames;
xColumn = find(strcmpi(variableNames,'X'),1,'first');
yColumn = find(strcmpi(variableNames,'Y'),1,'first');
if isempty(xColumn) || isempty(yColumn)
    error('reference_path_v17.csv must contain columns named X and Y.');
end
xRef = double(pathTable{:,xColumn});
yRef = double(pathTable{:,yColumn});
xRef = xRef(:);
yRef = yRef(:);
validPathRows = isfinite(xRef) & isfinite(yRef);
xRef = xRef(validPathRows);
yRef = yRef(validPathRows);
if numel(xRef) < 2
    error('Reference path must contain at least two finite points.');
end
% The supplied assignment path is 300 waypoints from X=0 m to X=12 m.
% Reject corrupted / differently scaled paths rather than silently plotting
% waypoint indices or percentages as metres.
if max(xRef)-min(xRef) > 20 || abs(xRef(1)) > 1.0 || ...
        abs(xRef(end)-12.0) > 1.0 || max(abs(yRef)) > 5.0
    error(['reference_path_v17.csv has unexpected coordinates. Expected a path ', ...
        'near X=0..12 m and |Y|<5 m; check that the supplied V17 CSV was copied correctly.']);
end
referenceArcLength = [0; cumsum(hypot(diff(xRef),diff(yRef)))];
if any(diff(referenceArcLength) < -1e-12) || referenceArcLength(end) <= 0
    error('Reference path arc length is invalid.');
end

s = size(xRef);
tRef = linspace(0,Ts,numel(xRef))';
X_o = xRef(1);
Y_o = yRef(1);
refPose = [xRef yRef];

fprintf('Dataset             : reference_path_v17.csv (verified 0-12 m project path)\n');
fprintf('Number of waypoints : %d\n',numel(xRef));
fprintf('Start               : (%.3f, %.3f) m\n',X_o,Y_o);
fprintf('Goal                : (%.3f, %.3f) m\n',xRef(end),yRef(end));

%% ==============================================================
% PUSH ALL SIMULINK VARIABLES TO BASE WORKSPACE
% ==============================================================

pushVariablesToBase( ...
    xRef,yRef,Ts,s,tRef, ...
    wheelRadius,trackWidth,robotRadius, ...
    v_const,ld,omega_max, ...
    X_o,Y_o,psi_o, ...
    stanleyGain,stanleyLength,refPose);

fprintf('\nSimulink workspace variables initialized.\n');

%% ==============================================================
% LOAD MODELS
% ==============================================================

ppModel = 'purePursuitDiffDriveRobot_baseline';
stModel = 'stanleyDiffDriveRobot';

fprintf('\n============================================================\n');
fprintf(' STEP 2 - LOAD SIMULINK MODELS\n');
fprintf('============================================================\n');

if ~isfile([ppModel '.slx'])
    error('%s.slx was not found.',ppModel);
end

if ~isfile([stModel '.slx'])
    error('%s.slx was not found.',stModel);
end

if bdIsLoaded(ppModel)
    close_system(ppModel,0);
end

if bdIsLoaded(stModel)
    close_system(stModel,0);
end

load_system([ppModel '.slx']);
load_system([stModel '.slx']);

fprintf('Loaded: %s\n',ppModel);
fprintf('Loaded: %s\n',stModel);

%% ==============================================================
% CONFIGURE PURE PURSUIT MODEL
% ==============================================================

fprintf('\n============================================================\n');
fprintf(' STEP 3 - CONFIGURE PURE PURSUIT MODEL\n');
fprintf('============================================================\n');

checkBlocks(ppModel,{ ...
    'Robot_New', ...
    'X Reference', ...
    'Y Reference', ...
    'Pose', ...
    'ObstacleAvoidance', ...
    'Obstacle X', ...
    'Obstacle Y', ...
    'Obstacle Radius', ...
    'Safe Distance'});

fprintf('Pure Pursuit model verified.\n');

%% ==============================================================
% CONFIGURE STANLEY MODEL
% ==============================================================

fprintf('\n============================================================\n');
fprintf(' STEP 4 - CONFIGURE STANLEY MODEL\n');
fprintf('============================================================\n');

configureStanleyModel( ...
    stModel, ...
    xRef, ...
    yRef, ...
    stanleyGain, ...
    stanleyLength, ...
    v_const, ...
    omega_max);

fprintf('Stanley model configured.\n');

%% ==============================================================
% BASELINE OBSTACLE SETTINGS
% ==============================================================

setObstacle( ...
    ppModel, ...
    baselineObstacleX, ...
    baselineObstacleY, ...
    obstacleRadius, ...
    safeDistance);

setObstacle( ...
    stModel, ...
    baselineObstacleX, ...
    baselineObstacleY, ...
    obstacleRadius, ...
    safeDistance);

save_system(ppModel);
save_system(stModel);

%% ==============================================================
% PURE PURSUIT BASELINE SIMULATION
% ==============================================================

fprintf('\n============================================================\n');
fprintf(' STEP 5 - PURE PURSUIT BASELINE SIMULATION\n');
fprintf('============================================================\n');

pushVariablesToBase( ...
    xRef,yRef,Ts,s,tRef, ...
    wheelRadius,trackWidth,robotRadius, ...
    v_const,ld,omega_max, ...
    X_o,Y_o,psi_o, ...
    stanleyGain,stanleyLength,refPose);

set_param(ppModel,'SimulationCommand','update');

simOutPP = sim(ppModel);

fprintf('Pure Pursuit simulation completed successfully.\n');



fprintf('\n============================================================\n');
fprintf(' STEP 6 - STANLEY BASELINE SIMULATION\n');
fprintf('============================================================\n');

pushVariablesToBase( ...
    xRef,yRef,Ts,s,tRef, ...
    wheelRadius,trackWidth,robotRadius, ...
    v_const,ld,omega_max, ...
    X_o,Y_o,psi_o, ...
    stanleyGain,stanleyLength,refPose);

set_param(stModel,'SimulationCommand','update');

simOutST = sim(stModel);

fprintf('Stanley simulation completed successfully.\n');



fprintf('\n============================================================\n');
fprintf(' STEP 7 - BASELINE PERFORMANCE\n');
fprintf('============================================================\n');

ppBase = calculateMetrics(simOutPP,xRef,yRef);
stBase = calculateMetrics(simOutST,xRef,yRef);

fprintf('\n');
fprintf('------------------------------------------------------------\n');
fprintf('%-30s %-15s %-15s\n', ...
    'Metric','Pure Pursuit','Stanley');
fprintf('------------------------------------------------------------\n');

fprintf('%-30s %-15.6f %-15.6f\n', ...
    'Mean CTE (m)', ...
    ppBase.meanCTE,stBase.meanCTE);

fprintf('%-30s %-15.6f %-15.6f\n', ...
    'RMSE CTE (m)', ...
    ppBase.rmseCTE,stBase.rmseCTE);

fprintf('%-30s %-15.6f %-15.6f\n', ...
    'Maximum CTE (m)', ...
    ppBase.maxCTE,stBase.maxCTE);

fprintf('%-30s %-15.6f %-15.6f\n', ...
    'Mean Heading Error (rad)', ...
    ppBase.meanHeading,stBase.meanHeading);

fprintf('%-30s %-15.6f %-15.6f\n', ...
    'Maximum Heading Error (rad)', ...
    ppBase.maxHeading,stBase.maxHeading);

fprintf('%-30s %-15.6f %-15.6f\n', ...
    'Closest Goal Distance (m)', ...
    ppBase.closestGoal,stBase.closestGoal);

fprintf('%-30s %-15.3f %-15.3f\n', ...
    'Time to Closest Goal (s)', ...
    ppBase.goalTime,stBase.goalTime);

fprintf('------------------------------------------------------------\n');



figure( ...
    'Name','01 - Baseline Trajectory', ...
    'Color','w');

plot(xRef,yRef,'--','LineWidth',2);
hold on;

plot(ppBase.x,ppBase.y,'LineWidth',2);
plot(stBase.x,stBase.y,'LineWidth',2);

scatter(xRef(1),yRef(1),80,'filled');
scatter(xRef(end),yRef(end),100,'filled');

grid on;
axis equal;

xlabel('X Position (m)');
ylabel('Y Position (m)');

title({ ...
    'Autonomous Mobile Robot Path Tracking'
    'Pure Pursuit vs Stanley'});

legend( ...
    'Reference Path', ...
    'Pure Pursuit', ...
    'Stanley', ...
    'Start', ...
    'Goal', ...
    'Location','best');

saveFigure(outputFolder,'01_baseline_trajectory.png');



figure( ...
    'Name','02 - Cross Track Error', ...
    'Color','w');

plot(ppBase.t,abs(ppBase.cte),'LineWidth',1.8);
hold on;

plot(stBase.t,abs(stBase.cte),'LineWidth',1.8);

grid on;

xlabel('Time (s)');
ylabel('Absolute Cross-Track Error (m)');

title({ ...
    'Autonomous Mobile Robot Path Tracking'
    'Cross-Track Error: Pure Pursuit vs Stanley'});

legend( ...
    'Pure Pursuit', ...
    'Stanley', ...
    'Location','best');

saveFigure(outputFolder,'02_cross_track_error.png');

%% ==============================================================
% GRAPH 3 - HEADING ERROR
% ==============================================================

figure( ...
    'Name','03 - Heading Error', ...
    'Color','w');

plot( ...
    ppBase.t, ...
    abs(ppBase.headingError), ...
    'LineWidth',1.8);

hold on;

plot( ...
    stBase.t, ...
    abs(stBase.headingError), ...
    'LineWidth',1.8);

grid on;

xlabel('Time (s)');
ylabel('Absolute Heading Error (rad)');

title({ ...
    'Autonomous Mobile Robot Path Tracking'
    'Heading Error: Pure Pursuit vs Stanley'});

legend( ...
    'Pure Pursuit', ...
    'Stanley', ...
    'Location','best');

saveFigure(outputFolder,'03_heading_error.png');

%% ==============================================================
% GRAPH 4 - PERFORMANCE COMPARISON
% ==============================================================

figure( ...
    'Name','04 - Performance Comparison', ...
    'Color','w');

performanceValues = [ ...
    ppBase.rmseCTE,stBase.rmseCTE;
    ppBase.maxCTE,stBase.maxCTE;
    ppBase.meanHeading,stBase.meanHeading];

bar(performanceValues);

grid on;

xlabel('Performance Metric');
ylabel('Value');

title({ ...
    'Autonomous Mobile Robot Path Tracking'
    'Controller Performance Comparison'});

xticklabels({ ...
    'RMSE CTE', ...
    'Maximum CTE', ...
    'Mean Heading Error'});

legend( ...
    'Pure Pursuit', ...
    'Stanley', ...
    'Location','best');

saveFigure(outputFolder,'04_performance_comparison.png');


%% ==============================================================
% STEP 8 - DYNAMIC OBSTACLE EXPERIMENTS
% ==============================================================

fprintf('\n============================================================\n');
fprintf(' STEP 8 - DYNAMIC OBSTACLE EXPERIMENTS\n');
fprintf('============================================================\n');

% Keep the original Pure Pursuit and Stanley models as baseline models.
% Dynamic obstacle logic is added to separate copies so baseline results
% remain reproducible and the original models can be restored anytime.
save_system(ppModel);
save_system(stModel);

ppDynamicModel = 'purePursuitDiffDriveRobot_dynamicObstacle';
stDynamicModel = 'stanleyDiffDriveRobot_dynamicObstacle';

if bdIsLoaded(ppDynamicModel)
    close_system(ppDynamicModel,0);
end
if bdIsLoaded(stDynamicModel)
    close_system(stDynamicModel,0);
end

ppCopyOk = copyfile([ppModel '.slx'],[ppDynamicModel '.slx'],'f');
stCopyOk = copyfile([stModel '.slx'],[stDynamicModel '.slx'],'f');
if ~ppCopyOk || ~stCopyOk
    error('Could not create dynamic-obstacle copies of the Simulink models.');
end

load_system([ppDynamicModel '.slx']);
load_system([stDynamicModel '.slx']);

% Obstacle experiment matrix: five correctly defined cases, each run with both controllers.
dynamicStopTime = 100;
predictionHorizon = 4.5;       % default for moving-obstacle cases
staticCaseHorizon = 1.40;       % shorter receding horizon for Case 2 (static obstacle)
predictionStep = 0.05;
scenarioCaseNumbers = [1, 2, 3, 4, 5];
% Robot nominal speed is v_const (0.22 m/s):
% Case 1: NO obstacle. A harmless placeholder is kept far outside the scene
% only because the generated Simulink function has fixed-size obstacle ports.
% Case 2: static obstacle at (staticObstacleX, staticObstacleY), speed = 0.
% Case 3: obstacle slower than robot (0.10 m/s).
% Case 4: obstacle speed equals robot speed (v_const).
% Case 5: obstacle faster than robot (0.30 m/s).
% Moving obstacles travel from goal to start, opposite to the robot.
dynamicSpeeds = [0.00, 0.00, 0.10, v_const, 0.30];
scenarioNames = { ...
    'CASE 1 - No obstacle', ...
    'CASE 2 - Static obstacle at (6.00, 0.45) m', ...
    'CASE 3 - Obstacle slower than robot (0.10 m/s)', ...
    'CASE 4 - Equal robot and obstacle speed (0.22 m/s)', ...
    'CASE 5 - Obstacle faster than robot (0.30 m/s)'};

if numel(dynamicSpeeds) ~= 5 || numel(scenarioNames) ~= 5 || ...
        numel(scenarioCaseNumbers) ~= 5 || ...
        abs(dynamicSpeeds(1)) > 1e-12 || ...
        abs(dynamicSpeeds(2)) > 1e-12 || ...
        dynamicSpeeds(3) >= v_const || ...
        abs(dynamicSpeeds(4)-v_const) > 1e-12 || ...
        dynamicSpeeds(5) <= v_const
    error('Cases 1-5 are not configured correctly.');
end

% Keep speed and geometry identical between the PP and Stanley runs.
assignin('base','robotRadius',robotRadius);
assignin('base','obstacleRadius',obstacleRadius);
assignin('base','safeDistance',safeDistance);
assignin('base','planningBuffer',planningBuffer);
assignin('base','omega_max',omega_max);
obstacleSpeed = v_const; % initial value required while compiling Constant blocks
assignin('base','obstacleSpeed',obstacleSpeed);
assignin('base','predictionHorizon',predictionHorizon);
assignin('base','predictionStep',predictionStep);
assignin('base','referenceArcLength',referenceArcLength);
assignin('base','obstacleX',staticObstacleX);
assignin('base','obstacleY',staticObstacleY);

configureDynamicObstacleModel(ppDynamicModel,numel(xRef));
configureDynamicObstacleModel(stDynamicModel,numel(xRef));

set_param(ppDynamicModel,'StopTime',num2str(dynamicStopTime));
set_param(stDynamicModel,'StopTime',num2str(dynamicStopTime));

save_system(ppDynamicModel);
save_system(stDynamicModel);

% Store simulation outputs and measurements:
% dimension 1 = scenario; dimension 2 = [Pure Pursuit, Stanley]
dynamicRunData = cell(numel(dynamicSpeeds),2);
dynamicRows = struct( ...
    'Scenario',{}, ...
    'Controller',{}, ...
    'ObstaclePresent',{}, ...
    'ObstacleSpeed_mps',{}, ...
    'RobotSpeed_mps',{}, ...
    'PredictionHorizon_s',{}, ...
    'MinimumCenterDistance_m',{}, ...
    'MinimumSurfaceGap_m',{}, ...
    'SafetyThreshold_m',{}, ...
    'SafetyMargin_m',{}, ...
    'CollisionDetected',{}, ...
    'SafetyThresholdViolated',{}, ...
    'GoalReached',{}, ...
    'GoalTime_s',{}, ...
    'ClosestGoalDistance_m',{}, ...
    'RMSE_CTE_m',{}, ...
    'Maximum_CTE_m',{}, ...
    'AvoidanceDuration_s',{}, ...
    'MinimumPredictedDistance_m',{});

modelList = {ppDynamicModel,stDynamicModel};
controllerLabels = {'Pure Pursuit','Stanley'};

for scenarioIdx = 1:numel(dynamicSpeeds)

    obstacleSpeed = dynamicSpeeds(scenarioIdx);
    obstaclePresent = scenarioIdx ~= 1;

    % Use receding-horizon prediction for the static obstacle. A long
    % constant-yaw rollout assumes the robot keeps turning for 4.5 s without
    % replanning, so it can reject every forward arc and choose v=0. The
    % supervisor is called repeatedly during simulation; a 1.40 s local
    % horizon lets it pick a short safe bypass arc and re-plan next step.
    scenarioPredictionHorizon = predictionHorizon;
    if scenarioIdx == 2
        scenarioPredictionHorizon = staticCaseHorizon;
    end

    if obstaclePresent
        scenarioObstacleX = staticObstacleX;
        scenarioObstacleY = staticObstacleY;
    else
        % Keep the fixed-size obstacle ports valid, but place the ignored
        % placeholder far outside the simulation/viewing area for Case 1.
        scenarioObstacleX = xRef(end) + 100;
        scenarioObstacleY = max(yRef) + 100;
    end
    assignin('base','obstacleSpeed',obstacleSpeed);
    assignin('base','obstacleX',scenarioObstacleX);
    assignin('base','obstacleY',scenarioObstacleY);
    assignin('base','predictionHorizon',scenarioPredictionHorizon);
    assignin('base','predictionStep',predictionStep);

    reportedObstacleSpeed = obstacleSpeed;
    if ~obstaclePresent
        reportedObstacleSpeed = NaN;
    end

    fprintf('\n------------------------------------------------------------\n');
    fprintf('CASE %d (simulation %d of %d): %s\n', ...
        scenarioCaseNumbers(scenarioIdx),scenarioIdx,numel(dynamicSpeeds), ...
        scenarioNames{scenarioIdx});
    fprintf('Robot nominal speed      : %.3f m/s\n',v_const);
    if ~obstaclePresent
        fprintf('Obstacle mode            : NONE (Case 1)\n');
    elseif scenarioIdx == 2
        fprintf('Obstacle mode            : STATIC at (%.2f, %.2f) m\n',staticObstacleX,staticObstacleY);
    else
        fprintf('Obstacle speed magnitude : %.3f m/s\n',obstacleSpeed);
        fprintf('Obstacle direction       : Goal -> Start (reverse waypoints)\n');
    end
    fprintf('Prediction horizon       : %.2f s\n',scenarioPredictionHorizon);
    fprintf('Hard centre-distance limit: %.2f m\n',safeDistance);
    fprintf('Preferred extra buffer    : %.2f m\n',planningBuffer);
    fprintf('------------------------------------------------------------\n');

    for controllerIdx = 1:2

        thisModel = modelList{controllerIdx};
        thisController = controllerLabels{controllerIdx};

        set_param(thisModel,'SimulationCommand','update');
        simOut = sim(thisModel);

        fprintf('%s dynamic-obstacle simulation completed.\n',thisController);

        % Extract the robot and moving-obstacle trajectories.
        t = squeeze(simOut.tout); t = t(:);
        x = getSignal(simOut,'robotX');
        y = getSignal(simOut,'robotY');
        psi = getSignal(simOut,'robotPsi');

        xObs = getSignal(simOut,'obstacleXLog');
        yObs = getSignal(simOut,'obstacleYLog');
        vxObs = getSignal(simOut,'obstacleVxLog');
        vyObs = getSignal(simOut,'obstacleVyLog');
        safetyMode = getSignal(simOut,'avoidanceModeLog');
        predictedDistance = getSignal(simOut,'predictedSeparationLog');
        vSafeLog = getSignal(simOut,'safeVelocityLog');
        omegaSafeLog = getSignal(simOut,'safeOmegaLog');

        N = min([numel(t),numel(x),numel(y),numel(psi), ...
            numel(xObs),numel(yObs),numel(vxObs),numel(vyObs), ...
            numel(safetyMode),numel(predictedDistance), ...
            numel(vSafeLog),numel(omegaSafeLog)]);

        t = t(1:N);
        x = x(1:N);
        y = y(1:N);
        psi = psi(1:N);
        xObs = xObs(1:N);
        yObs = yObs(1:N);
        vxObs = vxObs(1:N);
        vyObs = vyObs(1:N);
        safetyMode = safetyMode(1:N);
        predictedDistance = predictedDistance(1:N);
        vSafeLog = vSafeLog(1:N);
        omegaSafeLog = omegaSafeLog(1:N);

        % Regression guard for the original bug: Case 1 assigns a far-away
        % placeholder to the Simulink workspace variable names obstacleX/Y.
        % The script's real static location is kept separately as
        % staticObstacleX/Y, so Case 2 must remain at (6.00, 0.45) m.
        if scenarioIdx == 2
            staticPositionError = hypot(xObs-staticObstacleX,yObs-staticObstacleY);
            if any(~isfinite(staticPositionError)) || max(staticPositionError) > 1e-3
                error(['Case 2 static-obstacle telemetry is incorrect. Expected ', ...
                    '(%.2f, %.2f) m throughout the run; check the Dynamic Obstacle Motion inputs.'], ...
                    staticObstacleX,staticObstacleY);
            end
        end

        if obstaclePresent
            centerDistance = hypot(xObs-x,yObs-y);
            % Include closest approach between adjacent logged samples, not just sample points.
            minCenterDistance = minimumContinuousCenterDistance(x,y,xObs,yObs);
            minSurfaceGap = minCenterDistance-(robotRadius+obstacleRadius);
            safetyMargin = minCenterDistance-safeDistance;
            collisionDetected = minCenterDistance <= (robotRadius+obstacleRadius+1e-6);
            safetyThresholdViolated = any(centerDistance < safeDistance) || minCenterDistance < safeDistance;
        else
            % Case 1 has no physical obstacle, so collision-distance metrics
            % are not applicable (rather than measuring distance to the placeholder).
            centerDistance = nan(size(x));
            minCenterDistance = NaN;
            minSurfaceGap = NaN;
            safetyMargin = NaN;
            collisionDetected = false;
            safetyThresholdViolated = false;
            predictedDistance = nan(size(predictedDistance));
        end

        goalDistance = hypot(x-xRef(end),y-yRef(end));
        goalIdx = find(goalDistance <= 0.10,1,'first');
        goalReached = ~isempty(goalIdx);
        if goalReached
            goalTime = t(goalIdx);
        else
            goalTime = NaN;
        end

        [closestGoalDistance,~] = min(goalDistance);

        metricResult = calculateMetrics(simOut,xRef,yRef);

        if N > 1
            sampleIntervals = diff(t);
            sampleIntervals = sampleIntervals(sampleIntervals > 0);
            if isempty(sampleIntervals)
                nominalDt = 0;
            else
                nominalDt = median(sampleIntervals);
            end
            avoidanceDuration = sum(sampleIntervals .* ...
                double(safetyMode(1:end-1) > 0));
        else
            nominalDt = 0;
            avoidanceDuration = 0;
        end

        validPredicted = predictedDistance(isfinite(predictedDistance));
        if isempty(validPredicted)
            minPredictedDistance = NaN;
        else
            minPredictedDistance = min(validPredicted);
        end

        dynamicRunData{scenarioIdx,controllerIdx} = struct( ...
            'simOut',simOut, ...
            'obstaclePresent',obstaclePresent, ...
            'obstacleSpeedNominal',reportedObstacleSpeed, ...
            'predictionHorizon',scenarioPredictionHorizon, ...
            't',t, ...
            'x',x, ...
            'y',y, ...
            'psi',psi, ...
            'xObs',xObs, ...
            'yObs',yObs, ...
            'vxObs',vxObs, ...
            'vyObs',vyObs, ...
            'centerDistance',centerDistance, ...
            'safetyMode',safetyMode, ...
            'predictedDistance',predictedDistance, ...
            'vSafeLog',vSafeLog, ...
            'omegaSafeLog',omegaSafeLog, ...
            'metrics',metricResult, ...
            'minCenterDistance',minCenterDistance, ...
            'minSurfaceGap',minSurfaceGap, ...
            'safetyMargin',safetyMargin, ...
            'collisionDetected',collisionDetected, ...
            'safetyThresholdViolated',safetyThresholdViolated, ...
            'goalReached',goalReached, ...
            'goalTime',goalTime, ...
            'closestGoalDistance',closestGoalDistance);

        dynamicRows(end+1) = struct( ... %#ok<AGROW>
            'Scenario',scenarioNames{scenarioIdx}, ...
            'Controller',thisController, ...
            'ObstaclePresent',obstaclePresent, ...
            'ObstacleSpeed_mps',reportedObstacleSpeed, ...
            'RobotSpeed_mps',v_const, ...
            'PredictionHorizon_s',scenarioPredictionHorizon, ...
            'MinimumCenterDistance_m',minCenterDistance, ...
            'MinimumSurfaceGap_m',minSurfaceGap, ...
            'SafetyThreshold_m',safeDistance, ...
            'SafetyMargin_m',safetyMargin, ...
            'CollisionDetected',collisionDetected, ...
            'SafetyThresholdViolated',safetyThresholdViolated, ...
            'GoalReached',goalReached, ...
            'GoalTime_s',goalTime, ...
            'ClosestGoalDistance_m',closestGoalDistance, ...
            'RMSE_CTE_m',metricResult.rmseCTE, ...
            'Maximum_CTE_m',metricResult.maxCTE, ...
            'AvoidanceDuration_s',avoidanceDuration, ...
            'MinimumPredictedDistance_m',minPredictedDistance);

        % Save the full trajectory and obstacle telemetry for each run.
        tokenScenario = scenarioToken(scenarioNames{scenarioIdx});
        tokenController = strrep(lower(thisController),' ','_');
        trajectoryTable = table( ...
            t,x,y,psi,xObs,yObs,vxObs,vyObs,centerDistance, ...
            vSafeLog,omegaSafeLog,safetyMode,predictedDistance, ...
            'VariableNames',{ ...
            'Time_s','RobotX_m','RobotY_m','RobotHeading_rad', ...
            'ObstacleX_m','ObstacleY_m','ObstacleVx_mps','ObstacleVy_mps', ...
            'CenterDistance_m','SafeLinearVelocity_mps','SafeAngularVelocity_radps', ...
            'SafetyMode','PredictedMinDistance_m'});
        writetable(trajectoryTable,fullfile(outputFolder, ...
            sprintf('trajectory_%s_%s.csv',tokenController,tokenScenario)));

        if obstaclePresent
            fprintf('  Minimum centre distance : %.3f m\n',minCenterDistance);
            fprintf('  Minimum surface gap     : %.3f m\n',minSurfaceGap);
            fprintf('  Safety margin           : %.3f m\n',safetyMargin);
        else
            fprintf('  Obstacle distance       : N/A (no obstacle in Case 1)\n');
        end
        fprintf('  Collision detected      : %d\n',collisionDetected);
        fprintf('  Safety threshold crossed: %d\n',safetyThresholdViolated);
        if goalReached
            fprintf('  Goal reached at         : %.2f s\n',goalTime);
        else
            fprintf('  Goal reached            : NO (closest %.3f m)\n',closestGoalDistance);
        end
    end
end

dynamicResultsTable = struct2table(dynamicRows);

fprintf('\n============================================================\n');
fprintf(' DYNAMIC OBSTACLE RESULTS\n');
fprintf('============================================================\n');
disp(dynamicResultsTable);

writetable(dynamicResultsTable,fullfile(outputFolder, ...
    'dynamic_obstacle_results.csv'));

% A compact, easy-to-show collision summary for presentations/reviews.
summaryColumns = {'Scenario','Controller','ObstaclePresent','CollisionDetected', ...
    'MinimumCenterDistance_m','MinimumSurfaceGap_m', ...
    'SafetyThresholdViolated','GoalReached','GoalTime_s'};
collisionSummaryTable = dynamicResultsTable(:,summaryColumns);
writetable(collisionSummaryTable,fullfile(outputFolder, ...
    'dynamic_obstacle_collision_summary.csv'));

%% ==============================================================
% GRAPH 5 - TRAJECTORY COMPARISON FOR ALL SPEED SCENARIOS
% ==============================================================

figure('Name','05 - Dynamic Obstacle Trajectories','Color','w');
tiledlayout(2,3,'TileSpacing','compact','Padding','compact');

for scenarioIdx = 1:numel(dynamicSpeeds)
    ax = nexttile;
    hold(ax,'on');

    plot(ax,xRef,yRef,'k--','LineWidth',1.8,'DisplayName','Reference path');

    for controllerIdx = 1:2
        data = dynamicRunData{scenarioIdx,controllerIdx};
        plot(ax,data.x,data.y,'LineWidth',1.7, ...
            'DisplayName',controllerLabels{controllerIdx});

        if scenarioIdx >= 3
            validDistances = data.centerDistance(isfinite(data.centerDistance));
            if ~isempty(validDistances)
                [~,closestIdx] = min(data.centerDistance);
                scatter(ax,data.xObs(closestIdx),data.yObs(closestIdx),65,'filled', ...
                    'DisplayName',[controllerLabels{controllerIdx} ' closest encounter']);
            end
        end
    end

    if scenarioIdx == 1
        text(ax,0.04,0.94,'NO OBSTACLE','Units','normalized', ...
            'FontWeight','bold','Color',[0.05 0.45 0.12]);
    elseif scenarioIdx == 2
        scatter(ax,staticObstacleX,staticObstacleY,95,'o','filled', ...
            'DisplayName','Static obstacle');
    else
        scatter(ax,xRef(end),yRef(end),85,'p','filled','DisplayName','Obstacle start');
    end
    scatter(ax,xRef(1),yRef(1),65,'s','filled','DisplayName','Robot start');

    axis(ax,'equal');
    grid(ax,'on');
    xlabel(ax,'X Position (m)');
    ylabel(ax,'Y Position (m)');
    title(ax,scenarioNames{scenarioIdx},'Interpreter','none');
end

lgd = legend('Location','southoutside','Orientation','horizontal');
lgd.Layout.Tile = 'south';
sgtitle('Dynamic Obstacle Avoidance: Pure Pursuit vs Stanley');
saveFigure(outputFolder,'05_dynamic_obstacle_trajectories.png');

%% ==============================================================
% GRAPH 6 - OBSTACLE DISTANCE VS TIME
% ==============================================================

figure('Name','06 - Dynamic Obstacle Distance','Color','w');
tiledlayout(numel(dynamicSpeeds),1,'TileSpacing','compact','Padding','compact');

for scenarioIdx = 1:numel(dynamicSpeeds)
    ax = nexttile;
    hold(ax,'on');
    grid(ax,'on');
    xlabel(ax,'Time (s)');
    ylabel(ax,'Centre distance (m)');
    title(ax,scenarioNames{scenarioIdx},'Interpreter','none');
    if scenarioIdx == 1
        text(ax,0.5,0.5,'No obstacle — distance is not applicable', ...
            'Units','normalized','HorizontalAlignment','center');
        continue;
    end
    for controllerIdx = 1:2
        data = dynamicRunData{scenarioIdx,controllerIdx};
        plot(ax,data.t,data.centerDistance,'LineWidth',1.6, ...
            'DisplayName',controllerLabels{controllerIdx});
    end
    yline(ax,safeDistance,'k--','Safety threshold','LineWidth',1.3);
    legend(ax,'Location','best');
end

sgtitle('Robot-to-Obstacle Centre Distance');
saveFigure(outputFolder,'06_dynamic_obstacle_distance.png');

%% ==============================================================
% GRAPH 7 - SAFETY SUPERVISOR MODE
% ==============================================================

figure('Name','07 - Dynamic Safety Supervisor Modes','Color','w');
tiledlayout(numel(dynamicSpeeds),2,'TileSpacing','compact','Padding','compact');

for scenarioIdx = 1:numel(dynamicSpeeds)
    for controllerIdx = 1:2
        ax = nexttile;
        data = dynamicRunData{scenarioIdx,controllerIdx};
        stairs(ax,data.t,data.safetyMode,'LineWidth',1.2);
        grid(ax,'on');
        ylim(ax,[-0.2 4.2]);
        yticks(ax,0:4);
        yticklabels(ax,{'Normal','Steer','Slow','Emergency','Slow + turn'});
        xlabel(ax,'Time (s)');
        ylabel(ax,'Mode');
        title(ax,sprintf('%s | %s', ...
            scenarioNames{scenarioIdx},controllerLabels{controllerIdx}));
    end
end

sgtitle('Safety Supervisor Decision Over Time');
saveFigure(outputFolder,'07_dynamic_safety_modes.png');

%% ==============================================================
% SAVE BASELINE AND DYNAMIC RESULTS
% ==============================================================

Controller = {'Pure Pursuit';'Stanley'};
Mean_CTE = [ppBase.meanCTE;stBase.meanCTE];
RMSE_CTE = [ppBase.rmseCTE;stBase.rmseCTE];
Maximum_CTE = [ppBase.maxCTE;stBase.maxCTE];
Mean_Heading_Error = [ppBase.meanHeading;stBase.meanHeading];
Maximum_Heading_Error = [ppBase.maxHeading;stBase.maxHeading];
Closest_Goal_Distance = [ppBase.closestGoal;stBase.closestGoal];
Time_to_Closest_Goal = [ppBase.goalTime;stBase.goalTime];

resultsTable = table(Controller,Mean_CTE,RMSE_CTE,Maximum_CTE, ...
    Mean_Heading_Error,Maximum_Heading_Error,Closest_Goal_Distance, ...
    Time_to_Closest_Goal);

writetable(resultsTable,fullfile(outputFolder, ...
    'controller_comparison_results.csv'));

save(fullfile(outputFolder,'complete_project_results_dynamic.mat'), ...
    'resultsTable','dynamicResultsTable','ppBase','stBase', ...
    'xRef','yRef','dynamicSpeeds','scenarioNames','scenarioCaseNumbers','dynamicRunData', ...
    'v_const','robotRadius','obstacleRadius','safeDistance','staticObstacleX','staticObstacleY', ...
    'predictionHorizon','staticCaseHorizon','predictionStep','planningBuffer','-v7.3');

% Save lightweight data needed by the interactive viewer. This lets the
% user reopen/replay any of the ten runs later without re-running Simulink.
dynamicViewerRunData = cell(size(dynamicRunData));
for viewerScenarioIdx = 1:size(dynamicRunData,1)
    for viewerControllerIdx = 1:size(dynamicRunData,2)
        q = dynamicRunData{viewerScenarioIdx,viewerControllerIdx};
        dynamicViewerRunData{viewerScenarioIdx,viewerControllerIdx} = struct( ...
            'obstaclePresent',q.obstaclePresent, ...
            'obstacleSpeedNominal',q.obstacleSpeedNominal, ...
            'predictionHorizon',q.predictionHorizon, ...
            't',q.t,'x',q.x,'y',q.y,'psi',q.psi, ...
            'xObs',q.xObs,'yObs',q.yObs,'vxObs',q.vxObs,'vyObs',q.vyObs, ...
            'safetyMode',q.safetyMode,'predictedDistance',q.predictedDistance, ...
            'vSafeLog',q.vSafeLog,'omegaSafeLog',q.omegaSafeLog, ...
            'goalReached',q.goalReached,'goalTime',q.goalTime);
    end
end
viewerDataVersion = 17;
save(fullfile(outputFolder,'dynamic_obstacle_viewer_data.mat'), ...
    'viewerDataVersion','dynamicViewerRunData','xRef','yRef','robotRadius','obstacleRadius', ...
    'safeDistance','scenarioNames','scenarioCaseNumbers','controllerLabels','-v7');

%% ==============================================================
% 3D VISUALIZATION - ONE QUICK, INTERACTIVE DASHBOARD
% ==============================================================

if RUN_3D
    if exist('dynamicObstacleDashboard','file') == 2
        fprintf('\nOpening one interactive dashboard for all ten corrected case/controller runs...\n');
        fprintf('Playback starts PAUSED. Select a run, press PLAY, scrub backward, or change camera view.\n');
        dynamicObstacleDashboard(dynamicRunData,xRef,yRef,robotRadius, ...
            obstacleRadius,safeDistance,controllerLabels,scenarioNames,scenarioCaseNumbers);
    else
        warning(['dynamicObstacleDashboard.m was not found. ', ...
            'Copy it into the project folder to use the interactive obstacle viewer.']);
    end
end

%% ==============================================================
% FINAL SUMMARY
% ==============================================================

fprintf('\n============================================================\n');
fprintf(' DYNAMIC-OBSTACLE PROJECT RUN COMPLETE\n');
fprintf('============================================================\n');
fprintf('Baseline PP RMSE CTE : %.5f m\n',ppBase.rmseCTE);
fprintf('Baseline Stanley RMSE: %.5f m\n',stBase.rmseCTE);
fprintf('\nDynamic results saved to:\n%s\n',outputFolder);
fprintf('See dynamic_obstacle_results.csv, dynamic_obstacle_collision_summary.csv, trajectory CSVs, and dynamic_obstacle_viewer_data.mat.\n');
fprintf('Dynamic model copies:\n  %s.slx\n  %s.slx\n',ppDynamicModel,stDynamicModel);
fprintf('\nCases tested for BOTH controllers (10 simulations total):\n');
fprintf('  Case 1: NO obstacle\n');
fprintf('  Case 2: STATIC obstacle at (%.2f, %.2f) m (local horizon %.2f s)\n', ...
    staticObstacleX,staticObstacleY,staticCaseHorizon);
fprintf('  Case 3: slower obstacle (0.10 m/s vs robot %.2f m/s)\n',v_const);
fprintf('  Case 4: equal speed (%.2f m/s each)\n',v_const);
fprintf('  Case 5: faster obstacle (0.30 m/s vs robot %.2f m/s)\n',v_const);
fprintf('============================================================\n');

%% ==============================================================
% LOCAL FUNCTION: PUSH VARIABLES TO BASE WORKSPACE
% ==============================================================

function pushVariablesToBase( ...
    xRef,yRef,Ts,s,tRef, ...
    wheelRadius,trackWidth,robotRadius, ...
    v_const,ld,omega_max, ...
    X_o,Y_o,psi_o, ...
    stanleyGain,stanleyLength,refPose)

assignin('base','xRef',xRef);
assignin('base','yRef',yRef);

assignin('base','Ts',Ts);
assignin('base','s',s);
assignin('base','tRef',tRef);

assignin('base','wheelRadius',wheelRadius);
assignin('base','trackWidth',trackWidth);
assignin('base','robotRadius',robotRadius);

assignin('base','v_const',v_const);
assignin('base','ld',ld);
assignin('base','omega_max',omega_max);

assignin('base','X_o',X_o);
assignin('base','Y_o',Y_o);
assignin('base','psi_o',psi_o);

assignin('base','stanleyGain',stanleyGain);
assignin('base','stanleyLength',stanleyLength);

assignin('base','refPose',refPose);

end


%% ==============================================================
% LOCAL FUNCTION: CHECK BLOCKS
% ==============================================================

function checkBlocks(model,requiredBlocks)

for i = 1:numel(requiredBlocks)

    found = find_system( ...
        model, ...
        'SearchDepth',1, ...
        'Name',requiredBlocks{i});

    if isempty(found)

        error( ...
            'Required block "%s" is missing from "%s".', ...
            requiredBlocks{i},model);

    end

end

end


%% ==============================================================
% LOCAL FUNCTION: SET OBSTACLE
% ==============================================================

function setObstacle(model,x,y,radius,safe)

set_param( ...
    [model '/Obstacle X'], ...
    'Value',num2str(x));

set_param( ...
    [model '/Obstacle Y'], ...
    'Value',num2str(y));

set_param( ...
    [model '/Obstacle Radius'], ...
    'Value',num2str(radius));

set_param( ...
    [model '/Safe Distance'], ...
    'Value',num2str(safe));

end


%% ==============================================================
% LOCAL FUNCTION: ENSURE CONSTANT BLOCK
% ==============================================================

function ensureConstantBlock(model,name,value,position)

path = [model '/' name];

if isempty(find_system( ...
        model, ...
        'SearchDepth',1, ...
        'Name',name))

    add_block( ...
        'simulink/Sources/Constant', ...
        path, ...
        'Value',value, ...
        'Position',position);

else

    set_param(path,'Value',value);

end

end


%% ==============================================================
% LOCAL FUNCTION: REPLACE INPUT CONNECTION
% ==============================================================

function replaceInputConnection(model,dstPort,srcPort)

%% Remove any existing connection at the destination input.
% IMPORTANT: delete_line accepts a line handle directly. Passing the
% handle as the second argument makes MATLAB interpret it as a point
% matrix, which causes: 'Points matrix must have a minimum of two points'.
oldLine = get_param(dstPort,'Line');

if ~isempty(oldLine) && all(oldLine ~= -1)
    delete_line(oldLine);
end

% Resolve the parent blocks and port numbers.
% Using block/port strings is more robust here than passing raw port
% handles to add_line; it avoids the "Points matrix must have a minimum
% of two points" error that can occur after ports are created/updated.
srcParent = get_param(srcPort,'Parent');
dstParent = get_param(dstPort,'Parent');

if isnumeric(srcParent)
    srcBlock = getfullname(srcParent);
else
    srcBlock = char(srcParent);
end

if isnumeric(dstParent)
    dstBlock = getfullname(dstParent);
else
    dstBlock = char(dstParent);
end

srcNum = get_param(srcPort,'PortNumber');
dstNum = get_param(dstPort,'PortNumber');

% Convert full model paths to paths relative to the model passed to add_line.
prefix = [model '/'];
if startsWith(srcBlock,prefix)
    srcBlock = srcBlock(numel(prefix)+1:end);
end
if startsWith(dstBlock,prefix)
    dstBlock = dstBlock(numel(prefix)+1:end);
end

% Connect source output -> destination input.
add_line( ...
    model, ...
    [srcBlock '/' num2str(srcNum)], ...
    [dstBlock '/' num2str(dstNum)], ...
    'autorouting','on');

end


%% ==============================================================
% LOCAL FUNCTION: ENSURE OUTPUT CONNECTION
% ==============================================================

function ensureOutputConnection(model,srcPort,dstPort)

% Destination already has a line: keep it.
line = get_param(dstPort,'Line');

if ~isempty(line) && all(line ~= -1)
    return;
end

% Resolve parent blocks and port numbers and use block/port strings.
srcParent = get_param(srcPort,'Parent');
dstParent = get_param(dstPort,'Parent');

if isnumeric(srcParent)
    srcBlock = getfullname(srcParent);
else
    srcBlock = char(srcParent);
end

if isnumeric(dstParent)
    dstBlock = getfullname(dstParent);
else
    dstBlock = char(dstParent);
end

srcNum = get_param(srcPort,'PortNumber');
dstNum = get_param(dstPort,'PortNumber');

prefix = [model '/'];
if startsWith(srcBlock,prefix)
    srcBlock = srcBlock(numel(prefix)+1:end);
end
if startsWith(dstBlock,prefix)
    dstBlock = dstBlock(numel(prefix)+1:end);
end

add_line( ...
    model, ...
    [srcBlock '/' num2str(srcNum)], ...
    [dstBlock '/' num2str(dstNum)], ...
    'autorouting','on');

end


%% ==============================================================
% LOCAL FUNCTION: CONFIGURE STANLEY MODEL
% ==============================================================

function configureStanleyModel( ...
    model,xRef,yRef, ...
    stanleyGain,stanleyLength, ...
    v_const,omega_max)

%% --------------------------------------------------------------
% Verify model is loaded
% ---------------------------------------------------------------

if ~bdIsLoaded(model)

    load_system([model '.slx']);

end

%% --------------------------------------------------------------
% Ensure Stanley controller exists
% ---------------------------------------------------------------

controllerPath = [model '/Stanley Controller'];

if isempty(find_system( ...
        model, ...
        'SearchDepth',1, ...
        'Name','Stanley Controller'))

    add_block( ...
        'simulink/User-Defined Functions/MATLAB Function', ...
        controllerPath, ...
        'Position',[480 170 720 330]);

end

%% --------------------------------------------------------------
% Get EMChart
% ---------------------------------------------------------------

bd = get_param(model,'Object');

chart = find( ...
    bd, ...
    '-isa','Stateflow.EMChart', ...
    'Path',controllerPath);

if numel(chart) ~= 1

    error('Stanley Controller MATLAB Function block not found.');

end

%% --------------------------------------------------------------
% Stanley controller code
% ---------------------------------------------------------------

stanleyCode = sprintf([ ...
'function [omega,cte,headingError] = fcn(xRef,yRef,pose,v,k,L,omegaMax)\n' ...
'\n' ...
'x = pose(1);\n' ...
'y = pose(2);\n' ...
'psi = pose(3);\n' ...
'\n' ...
'%% Virtual front tracking point\n' ...
'xF = x + L*cos(psi);\n' ...
'yF = y + L*sin(psi);\n' ...
'\n' ...
'%% Find nearest reference point\n' ...
'n = length(xRef);\n' ...
'nearest = 1;\n' ...
'minDist = inf;\n' ...
'\n' ...
'for i = 1:n\n' ...
'    dx = xF - xRef(i);\n' ...
'    dy = yF - yRef(i);\n' ...
'    d = dx*dx + dy*dy;\n' ...
'    if d < minDist\n' ...
'        minDist = d;\n' ...
'        nearest = i;\n' ...
'    end\n' ...
'end\n' ...
'\n' ...
'%% Path heading\n' ...
'if nearest < n\n' ...
'    i0 = nearest;\n' ...
'    i1 = nearest + 1;\n' ...
'else\n' ...
'    i0 = n-1;\n' ...
'    i1 = n;\n' ...
'end\n' ...
'\n' ...
'pathHeading = atan2( ...\n' ...
'    yRef(i1)-yRef(i0), ...\n' ...
'    xRef(i1)-xRef(i0));\n' ...
'\n' ...
'%% Signed cross-track error\n' ...
'dx = xF - xRef(nearest);\n' ...
'dy = yF - yRef(nearest);\n' ...
'cte = -dx*sin(pathHeading) + dy*cos(pathHeading);\n' ...
'\n' ...
'%% Heading error\n' ...
'headingError = pathHeading - psi;\n' ...
'headingError = mod(headingError + pi,2*pi)-pi;\n' ...
'\n' ...
'%% Stanley correction\n' ...
'vSafe = max(abs(v),0.05);\n' ...
'correction = atan2(k*cte,vSafe);\n' ...
'\n' ...
'%% Sign convention for this differential-drive model\n' ...
'delta = headingError - correction;\n' ...
'\n' ...
'%% Limit steering-like quantity\n' ...
'delta = min(max(delta,-1.0),1.0);\n' ...
'\n' ...
'%% Convert steering command to differential-drive yaw rate\n' ...
'omega = (vSafe/L)*tan(delta);\n' ...
'\n' ...
'%% Angular velocity saturation\n' ...
'omega = min(max(omega,-omegaMax),omegaMax);\n' ...
'\n' ...
'end\n']);

chart.Script = stanleyCode;

%% Explicit dimensions
chart.Inputs(1).Props.Array.Size = ...
    sprintf('[%d 1]',numel(xRef));

chart.Inputs(2).Props.Array.Size = ...
    sprintf('[%d 1]',numel(yRef));

chart.Inputs(3).Props.Array.Size = '[3 1]';

chart.Inputs(4).Props.Array.Size = '1';
chart.Inputs(5).Props.Array.Size = '1';
chart.Inputs(6).Props.Array.Size = '1';
chart.Inputs(7).Props.Array.Size = '1';

chart.Outputs(1).Props.Array.Size = '1';
chart.Outputs(2).Props.Array.Size = '1';
chart.Outputs(3).Props.Array.Size = '1';

% Recompile/update now so the newly configured MATLAB Function ports
% and any newly created Constant blocks have valid handles.
set_param(model,'SimulationCommand','update');

%% --------------------------------------------------------------
% Create missing Stanley blocks automatically
% ---------------------------------------------------------------

ensureConstantBlock( ...
    model, ...
    'Stanley X Reference', ...
    'xRef', ...
    [120 100 270 130]);

ensureConstantBlock( ...
    model, ...
    'Stanley Y Reference', ...
    'yRef', ...
    [120 150 270 180]);

ensureConstantBlock( ...
    model, ...
    'Stanley Velocity', ...
    'v_const', ...
    [120 350 240 380]);

ensureConstantBlock( ...
    model, ...
    'Stanley Gain', ...
    'stanleyGain', ...
    [120 400 240 430]);

ensureConstantBlock( ...
    model, ...
    'Stanley Length', ...
    'stanleyLength', ...
    [120 450 240 480]);

ensureConstantBlock( ...
    model, ...
    'Stanley Omega Max', ...
    'omega_max', ...
    [120 500 240 530]);

%% --------------------------------------------------------------
% Get ports
% ---------------------------------------------------------------

stPH = get_param(controllerPath,'PortHandles');

xPH = get_param( ...
    [model '/Stanley X Reference'], ...
    'PortHandles');

yPH = get_param( ...
    [model '/Stanley Y Reference'], ...
    'PortHandles');

vPH = get_param( ...
    [model '/Stanley Velocity'], ...
    'PortHandles');

kPH = get_param( ...
    [model '/Stanley Gain'], ...
    'PortHandles');

lPH = get_param( ...
    [model '/Stanley Length'], ...
    'PortHandles');

oPH = get_param( ...
    [model '/Stanley Omega Max'], ...
    'PortHandles');

posePH = get_param( ...
    [model '/Pose'], ...
    'PortHandles');

oaPH = get_param( ...
    [model '/ObstacleAvoidance'], ...
    'PortHandles');

%% --------------------------------------------------------------
% Force correct Stanley input connections
% ---------------------------------------------------------------

replaceInputConnection( ...
    model, ...
    stPH.Inport(1), ...
    xPH.Outport(1));

replaceInputConnection( ...
    model, ...
    stPH.Inport(2), ...
    yPH.Outport(1));

replaceInputConnection( ...
    model, ...
    stPH.Inport(3), ...
    posePH.Outport(1));

replaceInputConnection( ...
    model, ...
    stPH.Inport(4), ...
    vPH.Outport(1));

replaceInputConnection( ...
    model, ...
    stPH.Inport(5), ...
    kPH.Outport(1));

replaceInputConnection( ...
    model, ...
    stPH.Inport(6), ...
    lPH.Outport(1));

replaceInputConnection( ...
    model, ...
    stPH.Inport(7), ...
    oPH.Outport(1));

%% --------------------------------------------------------------
% Force correct controller -> obstacle avoidance connections
% ---------------------------------------------------------------

replaceInputConnection( ...
    model, ...
    oaPH.Inport(1), ...
    vPH.Outport(1));

replaceInputConnection( ...
    model, ...
    oaPH.Inport(2), ...
    stPH.Outport(1));

%% --------------------------------------------------------------
% Create logging blocks
% ---------------------------------------------------------------

if isempty(find_system( ...
        model, ...
        'SearchDepth',1, ...
        'Name','Stanley CTE Log'))

    add_block( ...
        'simulink/Sinks/To Workspace', ...
        [model '/Stanley CTE Log'], ...
        'VariableName','stanleyCTE', ...
        'SaveFormat','Timeseries', ...
        'Position',[780 250 930 280]);

end

if isempty(find_system( ...
        model, ...
        'SearchDepth',1, ...
        'Name','Stanley Heading Error Log'))

    add_block( ...
        'simulink/Sinks/To Workspace', ...
        [model '/Stanley Heading Error Log'], ...
        'VariableName','stanleyHeadingError', ...
        'SaveFormat','Timeseries', ...
        'Position',[780 310 930 340]);

end

if isempty(find_system( ...
        model, ...
        'SearchDepth',1, ...
        'Name','Stanley Omega Log'))

    add_block( ...
        'simulink/Sinks/To Workspace', ...
        [model '/Stanley Omega Log'], ...
        'VariableName','stanleyOmega', ...
        'SaveFormat','Timeseries', ...
        'Position',[780 190 930 220]);

end

%% --------------------------------------------------------------
% Connect logs if they are not already connected
% ---------------------------------------------------------------

ctePH = get_param( ...
    [model '/Stanley CTE Log'], ...
    'PortHandles');

headPH = get_param( ...
    [model '/Stanley Heading Error Log'], ...
    'PortHandles');

omegaPH = get_param( ...
    [model '/Stanley Omega Log'], ...
    'PortHandles');

ensureOutputConnection( ...
    model, ...
    stPH.Outport(2), ...
    ctePH.Inport(1));

ensureOutputConnection( ...
    model, ...
    stPH.Outport(3), ...
    headPH.Inport(1));

ensureOutputConnection( ...
    model, ...
    stPH.Outport(1), ...
    omegaPH.Inport(1));

%% --------------------------------------------------------------
% Push parameters
% ---------------------------------------------------------------

assignin('base','xRef',xRef);
assignin('base','yRef',yRef);
assignin('base','stanleyGain',stanleyGain);
assignin('base','stanleyLength',stanleyLength);
assignin('base','v_const',v_const);
assignin('base','omega_max',omega_max);

%% Compile
set_param(model,'SimulationCommand','update');

%% Final verification
if length(stPH.Inport) ~= 7 || length(stPH.Outport) ~= 3
    error('Stanley controller must have 7 inputs and 3 outputs.');
end

end


%% ==============================================================
% LOCAL FUNCTION: GET SIGNAL
% ==============================================================

function data = getSignal(simOut,name)

fields = simOut.who;

if ~any(strcmp(fields,name))

    error( ...
        'Simulation output "%s" was not found.', ...
        name);

end

value = simOut.(name);

if isa(value,'timeseries')

    data = value.Data;

else

    data = value;

end

data = squeeze(data);
data = data(:);

end


%% ==============================================================
% LOCAL FUNCTION: CALCULATE METRICS
% ==============================================================

function result = calculateMetrics(simOut,xRef,yRef)

x = getSignal(simOut,'robotX');
y = getSignal(simOut,'robotY');
psi = getSignal(simOut,'robotPsi');

t = squeeze(simOut.tout);
t = t(:);

N = min([ ...
    numel(x), ...
    numel(y), ...
    numel(psi), ...
    numel(t)]);

x = x(1:N);
y = y(1:N);
psi = psi(1:N);
t = t(1:N);

xRef = xRef(:);
yRef = yRef(:);

nRef = numel(xRef);

nearest = zeros(N,1);

for k = 1:N

    d = hypot( ...
        xRef-x(k), ...
        yRef-y(k));

    [~,nearest(k)] = min(d);

end

completionThreshold = max(nRef-2,1);

evalIndex = find( ...
    nearest >= completionThreshold, ...
    1,'first');

if isempty(evalIndex)
    evalIndex = N;
end

x = x(1:evalIndex);
y = y(1:evalIndex);
psi = psi(1:evalIndex);
t = t(1:evalIndex);

nearest = nearest(1:evalIndex);

M = numel(x);

cte = zeros(M,1);
headingError = zeros(M,1);

for k = 1:M

    idx = nearest(k);

    if idx < nRef

        idx2 = idx + 1;

    else

        idx2 = idx;
        idx = max(idx-1,1);

    end

    pathHeading = atan2( ...
        yRef(idx2)-yRef(idx), ...
        xRef(idx2)-xRef(idx));

    ex = x(k)-xRef(idx);
    ey = y(k)-yRef(idx);

    cte(k) = ...
        ex*sin(pathHeading) - ...
        ey*cos(pathHeading);

    headingError(k) = ...
        pathHeading - psi(k);

    headingError(k) = ...
        mod(headingError(k)+pi,2*pi)-pi;

end

goalX = xRef(end);
goalY = yRef(end);

goalDistance = hypot( ...
    x-goalX, ...
    y-goalY);

[closestGoal,goalIndex] = min(goalDistance);

result.meanCTE = mean(abs(cte));
result.rmseCTE = sqrt(mean(cte.^2));
result.maxCTE = max(abs(cte));

result.meanHeading = ...
    mean(abs(headingError));

result.maxHeading = ...
    max(abs(headingError));

result.closestGoal = closestGoal;
result.goalTime = t(goalIndex);

result.x = x;
result.y = y;
result.psi = psi;
result.t = t;

result.cte = cte;
result.headingError = headingError;

end


%% ==============================================================
% LOCAL FUNCTION: SAVE FIGURE
% ==============================================================

function saveFigure(outputFolder,fileName)

filePath = fullfile( ...
    outputFolder, ...
    fileName);

try

    exportgraphics( ...
        gcf, ...
        filePath, ...
        'Resolution',200);

catch

    saveas( ...
        gcf, ...
        filePath);

end

end


%% ==============================================================
% LOCAL FUNCTION: CONFIGURE DYNAMIC OBSTACLE AND SAFETY SUPERVISOR
% ==============================================================

function configureDynamicObstacleModel(model,nRef)

% Create time source and parameter constants.
ensureBlock(model,'simulink/Sources/Clock','Obstacle Clock', ...
    [250 760 280 790]);

ensureConstantBlock(model,'Obstacle Speed','obstacleSpeed', ...
    [300 820 410 850]);
ensureConstantBlock(model,'Robot Radius','robotRadius', ...
    [300 865 410 895]);
ensureConstantBlock(model,'Robot Target Speed','v_const', ...
    [300 1000 410 1030]);
ensureConstantBlock(model,'Planning Buffer','planningBuffer', ...
    [300 1045 410 1075]);
ensureConstantBlock(model,'Prediction Horizon','predictionHorizon', ...
    [300 910 410 940]);
ensureConstantBlock(model,'Prediction Step','predictionStep', ...
    [300 955 410 985]);
ensureConstantBlock(model,'Reference Arc Length','referenceArcLength', ...
    [300 1090 430 1120]);
ensureConstantBlock(model,'Static Obstacle X','obstacleX', ...
    [300 1135 410 1165]);
ensureConstantBlock(model,'Static Obstacle Y','obstacleY', ...
    [300 1180 410 1210]);

% Dynamic obstacle motion function:
% reverse-traverses the path when speed > 0; speed = 0 holds a static coordinate.
dynamicCode = strjoin({
'function [xObs,yObs,vObsX,vObsY] = fcn(t,xRef,yRef,speed,staticX,staticY)'
'%#codegen'
'n = length(xRef);'
'xObs = xRef(n);'
'yObs = yRef(n);'
'vObsX = 0;'
'vObsY = 0;'
'if abs(speed) <= 1.0e-9'
'    xObs = staticX;'
'    yObs = staticY;'
'    return;'
'end'
'if n < 2'
'    return;'
'end'
'sPath = zeros(n,1);'
'for k = 2:n'
'    dxPath = xRef(k)-xRef(k-1);'
'    dyPath = yRef(k)-yRef(k-1);'
'    sPath(k) = sPath(k-1) + hypot(dxPath,dyPath);'
'end'
'totalLength = sPath(n);'
'travelled = abs(speed)*max(t,0);'
'targetS = totalLength-travelled;'
'if targetS <= 0'
'    xObs = xRef(1);'
'    yObs = yRef(1);'
'    vObsX = 0;'
'    vObsY = 0;'
'    return;'
'end'
'segment = n-1;'
'for k = 1:n-1'
'    if targetS >= sPath(k) && targetS <= sPath(k+1)'
'        segment = k;'
'        break;'
'    end'
'end'
'segmentLength = sPath(segment+1)-sPath(segment);'
'if segmentLength <= 1e-9'
'    xObs = xRef(segment);'
'    yObs = yRef(segment);'
'    vObsX = 0;'
'    vObsY = 0;'
'else'
'    fraction = (targetS-sPath(segment))/segmentLength;'
'    fraction = min(max(fraction,0),1);'
'    dxSeg = xRef(segment+1)-xRef(segment);'
'    dySeg = yRef(segment+1)-yRef(segment);'
'    xObs = xRef(segment)+fraction*dxSeg;'
'    yObs = yRef(segment)+fraction*dySeg;'
'    vObsX = -abs(speed)*dxSeg/segmentLength;'
'    vObsY = -abs(speed)*dySeg/segmentLength;'
'end'
'end'
},newline);

ensureMatlabFunctionBlock(model,'Dynamic Obstacle Motion', ...
    [500 760 760 900],dynamicCode, ...
    {'1',sprintf('[%d 1]',nRef),sprintf('[%d 1]',nRef),'1','1','1'}, ...
    {'1','1','1','1'});

% Predictive safety supervisor. This version predicts the obstacle along
% the exact reverse reference path at each future time, not a straight-line
% extrapolation of the instantaneous obstacle velocity. No persistent state
% is used, so the MATLAB Function block can compile without persistent-state
% / continuous-sample-time conflicts.
safetyCode = strjoin({
'function [vSafe,omegaSafe,minPredictedDistance,mode] = fcn(vNom,omegaNom,pose,xObs,yObs,vObsX,vObsY,obstacleRadius,robotRadius,safeDistance,omegaMax,horizon,predStep,baseSpeed,planningBuffer,tNow,xRef,yRef,sRef,obstacleSpeed,staticObstacleX,staticObstacleY)'
'%#codegen'
'x = pose(1);'
'y = pose(2);'
'psi = pose(3);'
'rawVReference = min(max(vNom,0),max(baseSpeed,0));'
'goalDistance = hypot(xRef(end)-x,yRef(end)-y);'
'goalStopRadius = 0.07;'
'goalSlowdownDistance = 0.85;'
'goalSpeedFraction = min(max((goalDistance-goalStopRadius)/goalSlowdownDistance,0),1);'
'vReference = min(rawVReference,max(baseSpeed,0)*goalSpeedFraction);'
'omegaMax = max(abs(omegaMax),0.05);'
'% Stop the robot at the final goal instead of letting Stanley continue along the tangent.'
'if goalDistance <= goalStopRadius'
'    vSafe = 0;'
'    omegaSafe = 0;'
'    minPredictedDistance = hypot(xObs-x,yObs-y);'
'    mode = 0;'
'    return;'
'end'
'omegaNom = min(max(omegaNom,-omegaMax),omegaMax);'
'physicalClearance = robotRadius + obstacleRadius + 0.03;'
'requiredDistance = max(safeDistance,physicalClearance);'
'preferredDistance = requiredDistance + max(planningBuffer,0);'
'dt = max(predStep,0.025);'
'maxPredictionSteps = 160;'
'nSteps = ceil(max(horizon,dt)/dt);'
'nSteps = min(max(nSteps,1),maxPredictionSteps);'
'currentDistance = hypot(xObs-x,yObs-y);'
'% Gentle distance-based slowdown: retain most speed, but make room for the diversion.'
'% Full nominal speed outside the approach band; gradually cap to 78% near the hard boundary.'
'approachSlowdownRange = 1.8;'
'minimumApproachSpeedFactor = 0.78;'
'approachFraction = min(max((currentDistance-requiredDistance)/approachSlowdownRange,0),1);'
'approachSpeedFactor = minimumApproachSpeedFactor + (1-minimumApproachSpeedFactor)*approachFraction;'
'vReference = min(vReference,rawVReference*approachSpeedFactor);'
'% Re-evaluate with the reduced approach speed so the following diversion search uses it.'
'% Precompute exact obstacle positions for all future samples once per control call.'
'xObsFuture = zeros(maxPredictionSteps,1);'
'yObsFuture = zeros(maxPredictionSteps,1);'
'for k = 1:nSteps'
'    [xObsFuture(k),yObsFuture(k)] = obstaclePositionAtTime(tNow+k*dt,xRef,yRef,sRef,obstacleSpeed,staticObstacleX,staticObstacleY);'
'end'
'[minNominal,minNominalFuture] = predictDistances(x,y,psi,vReference,omegaNom,xObs,yObs,xObsFuture,yObsFuture,dt,nSteps);'
'vSafe = vReference;'
'omegaSafe = omegaNom;'
'minPredictedDistance = minNominal;'
'mode = 0;'
'if minNominal >= preferredDistance && currentDistance >= requiredDistance'
'    return;'
'end'
'% Wider speed/turn grid allows a genuine forward arc around the obstacle.'
'% The absolute yaw-rate grid includes both escape directions even if the nominal command saturates.'
'speedScale = [1.0 0.85 0.70 0.55 0.40 0.25 0.10 0.0];'
'turnTargets = [-omegaMax -2.0 -1.6 -1.2 -0.9 -0.6 -0.4 -0.2 0.0 0.2 0.4 0.6 0.9 1.2 1.6 2.0 omegaMax omegaNom];'
'bestSafeCost = 1.0e30;'
'bestSafeV = vReference;'
'bestSafeOmega = omegaNom;'
'bestSafeDistance = minNominal;'
'safeFound = false;'
'% Track safe moving candidates separately from a stationary hold command.'
'% If a safe forward arc exists, prefer progressing around the obstacle instead of freezing in front of it.'
'bestMovingSafeCost = 1.0e30;'
'bestMovingSafeV = vReference;'
'bestMovingSafeOmega = omegaNom;'
'bestMovingSafeDistance = minNominal;'
'movingSafeFound = false;'
'bestEmergencyScore = -1.0e30;'
'bestEmergencyV = vReference;'
'bestEmergencyOmega = omegaNom;'
'bestEmergencyDistance = minNominal;'
'localY = -sin(psi)*(xObs-x)+cos(psi)*(yObs-y);'
'vDenom = max(vReference,0.05);'
'for i = 1:length(speedScale)'
'    vCandidate = speedScale(i)*vReference;'
'    for j = 1:length(turnTargets)'
'        omegaCandidate = min(max(turnTargets(j),-omegaMax),omegaMax);'
'        [dCandidate,futureDistance] = predictDistances(x,y,psi,vCandidate,omegaCandidate,xObs,yObs,xObsFuture,yObsFuture,dt,nSteps);'
'        turnChange = abs(omegaCandidate-omegaNom);'
'        turnPenalty = min(turnChange/1.4,1.0);'
'        speedLoss = max(0,(vReference-vCandidate)/vDenom);'
'        deltaOmega = omegaCandidate-omegaNom;'
'        sidePenalty = 0.0;'
'        if localY > 0.05 && deltaOmega > 0'
'            sidePenalty = 0.12; % obstacle on left: discourage steering left toward it'
'        elseif localY < -0.05 && deltaOmega < 0'
'            sidePenalty = 0.12; % obstacle on right: discourage steering right toward it'
'        elseif abs(localY) <= 0.05 && deltaOmega > 0'
'            sidePenalty = 0.025; % near head-on: deterministic initial preference to turn right'
'        end'
'        % Emergency score optimizes FUTURE separation, so an already-breached soft boundary'
'        % does not make every command look equally bad just because current distance is small.'
'        emergencyScore = futureDistance - 0.06*speedLoss - 0.05*turnPenalty - sidePenalty;'
'        if emergencyScore > bestEmergencyScore'
'            bestEmergencyScore = emergencyScore;'
'            bestEmergencyV = vCandidate;'
'            bestEmergencyOmega = omegaCandidate;'
'            bestEmergencyDistance = dCandidate;'
'        end'
'        % Normal admissibility requires the hard centre-distance limit for the full horizon.'
'        if currentDistance >= requiredDistance && dCandidate >= requiredDistance'
'            bufferWidth = max(preferredDistance-requiredDistance,0.01);'
'            clearanceDeficit = min(max((preferredDistance-dCandidate)/bufferWidth,0),1);'
'            absoluteTurnPenalty = min(abs(omegaCandidate)/max(omegaMax,0.1),1);'
'            progressRatio = min(max(vCandidate/max(vReference,0.05),0),1);'
'            % Weight collision clearance as a hard constraint, then favour forward progress.'
'            % This prevents the optimizer from preferring a safe stop when a safe passing arc exists.'
'            cost = 0.12*speedLoss + 0.14*turnPenalty + 0.02*absoluteTurnPenalty + 0.08*clearanceDeficit + sidePenalty - 0.35*progressRatio;'
'            if cost < bestSafeCost'
'                bestSafeCost = cost;'
'                bestSafeV = vCandidate;'
'                bestSafeOmega = omegaCandidate;'
'                bestSafeDistance = dCandidate;'
'                safeFound = true;'
'            end'
'            % Explicitly rank safe commands that move the robot forward above safe hold commands.'
'            if vCandidate > max(0.025,0.15*vReference) && cost < bestMovingSafeCost'
'                bestMovingSafeCost = cost;'
'                bestMovingSafeV = vCandidate;'
'                bestMovingSafeOmega = omegaCandidate;'
'                bestMovingSafeDistance = dCandidate;'
'                movingSafeFound = true;'
'            end'
'        end'
'    end'
'end'
'if movingSafeFound'
'    % A collision-free forward arc is available: take it rather than stopping in front of the obstacle.'
'    vSafe = bestMovingSafeV;'
'    omegaSafe = bestMovingSafeOmega;'
'    minPredictedDistance = bestMovingSafeDistance;'
'elseif safeFound'
'    % No progressing candidate satisfies the hard limit, so a safe hold/slow command is preferred.'
'    vSafe = bestSafeV;'
'    omegaSafe = bestSafeOmega;'
'    minPredictedDistance = bestSafeDistance;'
'end'
'if movingSafeFound || safeFound'
'    hasLargeTurn = abs(omegaSafe-omegaNom) > 0.25;'
'    hasSlowdown = vSafe < 0.90*vReference;'
'    if hasLargeTurn && hasSlowdown'
'        mode = 4;'
'    elseif hasLargeTurn'
'        mode = 1;'
'    elseif hasSlowdown'
'        mode = 2;'
'    else'
'        mode = 0;'
'    end'
'else'
'    % No sampled command can satisfy the hard limit for the entire horizon, or the robot is already inside it.'
'    % Select the command with the greatest predicted future separation, while still preferring limited control changes.'
'    vSafe = bestEmergencyV;'
'    omegaSafe = bestEmergencyOmega;'
'    minPredictedDistance = bestEmergencyDistance;'
'    mode = 3;'
'end'
'end'
''
'function [minDistance,minFutureDistance] = predictDistances(x0,y0,psi0,v,omega,xObs0,yObs0,xObsFuture,yObsFuture,dt,nSteps)'
'x = x0;'
'y = y0;'
'psi = psi0;'
'minDistance = hypot(xObs0-x0,yObs0-y0);'
'minFutureDistance = inf;'
'prevRelX = xObs0-x0;'
'prevRelY = yObs0-y0;'
'for k = 1:nSteps'
'    x = x + v*cos(psi)*dt;'
'    y = y + v*sin(psi)*dt;'
'    psi = mod(psi+omega*dt+pi,2*pi)-pi;'
'    relX = xObsFuture(k)-x;'
'    relY = yObsFuture(k)-y;'
'    pointDistance = hypot(relX,relY);'
'    if pointDistance < minDistance'
'        minDistance = pointDistance;'
'    end'
'    if pointDistance < minFutureDistance'
'        minFutureDistance = pointDistance;'
'    end'
'    relStepX = relX-prevRelX;'
'    relStepY = relY-prevRelY;'
'    denominator = relStepX*relStepX + relStepY*relStepY;'
'    if denominator > 1.0e-12'
'        alpha = -(prevRelX*relStepX + prevRelY*relStepY)/denominator;'
'        alpha = min(max(alpha,0),1);'
'        segmentDistance = hypot(prevRelX+alpha*relStepX,prevRelY+alpha*relStepY);'
'        if segmentDistance < minDistance'
'            minDistance = segmentDistance;'
'        end'
'        if k >= 2 && segmentDistance < minFutureDistance'
'            minFutureDistance = segmentDistance;'
'        end'
'    end'
'    prevRelX = relX;'
'    prevRelY = relY;'
'end'
'end'
''
'function [xo,yo] = obstaclePositionAtTime(tFuture,xRef,yRef,sRef,speed,staticX,staticY)'
'if abs(speed) <= 1.0e-9'
'    xo = staticX;'
'    yo = staticY;'
'    return;'
'end'
'n = length(xRef);'
'totalLength = sRef(n);'
'targetS = totalLength-abs(speed)*max(tFuture,0);'
'if targetS <= 0'
'    xo = xRef(1);'
'    yo = yRef(1);'
'    return;'
'end'
'if targetS >= totalLength'
'    xo = xRef(n);'
'    yo = yRef(n);'
'    return;'
'end'
'lo = 1;'
'hi = n;'
'while hi-lo > 1'
'    mid = floor((lo+hi)/2);'
'    if sRef(mid) <= targetS'
'        lo = mid;'
'    else'
'        hi = mid;'
'    end'
'end'
'segment = min(max(lo,1),n-1);'
'segmentLength = sRef(segment+1)-sRef(segment);'
'if segmentLength <= 1.0e-9'
'    xo = xRef(segment);'
'    yo = yRef(segment);'
'else'
'    fraction = (targetS-sRef(segment))/segmentLength;'
'    fraction = min(max(fraction,0),1);'
'    xo = xRef(segment)+fraction*(xRef(segment+1)-xRef(segment));'
'    yo = yRef(segment)+fraction*(yRef(segment+1)-yRef(segment));'
'end'
'end'
},newline);

ensureMatlabFunctionBlock(model,'Dynamic Safety Supervisor', ...
    [1230 760 1570 940],safetyCode, ...
    {'1','1','[3 1]','1','1','1','1','1','1','1','1','1','1','1','1','1', ...
     sprintf('[%d 1]',nRef),sprintf('[%d 1]',nRef),sprintf('[%d 1]',nRef),'1','1','1'}, ...
    {'1','1','1','1'});

% Configure the existing radius/safety constants so the supervisor sees
% the same geometry as the obstacle detector.
ensureConstantBlock(model,'Obstacle Radius','obstacleRadius', ...
    [420 610 500 640]);
ensureConstantBlock(model,'Safe Distance','safeDistance', ...
    [420 655 500 685]);
ensureConstantBlock(model,'Static Obstacle X','obstacleX', ...
    [420 700 500 730]);
ensureConstantBlock(model,'Static Obstacle Y','obstacleY', ...
    [420 745 500 775]);

% Ensure workspace logging sinks exist.
ensureWorkspaceBlock(model,'Dynamic Obstacle X Log','obstacleXLog',[850 770 1000 800]);
ensureWorkspaceBlock(model,'Dynamic Obstacle Y Log','obstacleYLog',[850 815 1000 845]);
ensureWorkspaceBlock(model,'Dynamic Obstacle Vx Log','obstacleVxLog',[850 860 1000 890]);
ensureWorkspaceBlock(model,'Dynamic Obstacle Vy Log','obstacleVyLog',[850 905 1000 935]);
ensureWorkspaceBlock(model,'Predicted Separation Log','predictedSeparationLog',[1600 780 1770 810]);
ensureWorkspaceBlock(model,'Avoidance Mode Log','avoidanceModeLog',[1600 830 1770 860]);
ensureWorkspaceBlock(model,'Safe Velocity Log','safeVelocityLog',[1600 880 1770 910]);
ensureWorkspaceBlock(model,'Safe Omega Log','safeOmegaLog',[1600 930 1770 960]);

% First update the model so all newly generated ports are valid.
set_param(model,'SimulationCommand','update');

% Ports for the dynamic obstacle motion block.
motionPH = get_param([model '/Dynamic Obstacle Motion'],'PortHandles');
clockPH = get_param([model '/Obstacle Clock'],'PortHandles');
speedPH = get_param([model '/Obstacle Speed'],'PortHandles');
xRefPH = get_param([model '/X Reference'],'PortHandles');
yRefPH = get_param([model '/Y Reference'],'PortHandles');

% Dynamic obstacle source inputs.
forceConnectByPath(model,'Obstacle Clock',1,'Dynamic Obstacle Motion',1);
forceConnectByPath(model,'X Reference',1,'Dynamic Obstacle Motion',2);
forceConnectByPath(model,'Y Reference',1,'Dynamic Obstacle Motion',3);
forceConnectByPath(model,'Obstacle Speed',1,'Dynamic Obstacle Motion',4);
forceConnectByPath(model,'Static Obstacle X',1,'Dynamic Obstacle Motion',5);
forceConnectByPath(model,'Static Obstacle Y',1,'Dynamic Obstacle Motion',6);

% Replace the old stationary obstacle coordinates at detector inputs 4 and 5.
forceConnectByPath(model,'Dynamic Obstacle Motion',1,'ObstacleDetector',4);
forceConnectByPath(model,'Dynamic Obstacle Motion',2,'ObstacleDetector',5);

% Feed obstacle telemetry to the logs.
forceConnectByPath(model,'Dynamic Obstacle Motion',1,'Dynamic Obstacle X Log',1);
forceConnectByPath(model,'Dynamic Obstacle Motion',2,'Dynamic Obstacle Y Log',1);
forceConnectByPath(model,'Dynamic Obstacle Motion',3,'Dynamic Obstacle Vx Log',1);
forceConnectByPath(model,'Dynamic Obstacle Motion',4,'Dynamic Obstacle Vy Log',1);

% Insert the predictive safety supervisor between nominal controller commands and robot.
% Connect supervisor outputs first so the old direct command lines are
% removed from Robot_New inputs.
forceConnectByPath(model,'Dynamic Safety Supervisor',1,'Robot_New',1);
forceConnectByPath(model,'Dynamic Safety Supervisor',2,'Robot_New',2);

% Feed the nominal path-tracking commands directly to the safety supervisor.
% This avoids stacking the legacy obstacle-avoidance turn with the new
% predictive supervisor, which previously caused unnecessarily large detours.
if contains(lower(model),'stanley')
    forceConnectByPath(model,'Stanley Velocity',1,'Dynamic Safety Supervisor',1);
    forceConnectByPath(model,'Stanley Controller',1,'Dynamic Safety Supervisor',2);
else
    forceConnectByPath(model,'Pure Pursuit',2,'Dynamic Safety Supervisor',1);
    forceConnectByPath(model,'Angular Velocity',1,'Dynamic Safety Supervisor',2);
end
forceConnectByPath(model,'Pose',1,'Dynamic Safety Supervisor',3);
forceConnectByPath(model,'Dynamic Obstacle Motion',1,'Dynamic Safety Supervisor',4);
forceConnectByPath(model,'Dynamic Obstacle Motion',2,'Dynamic Safety Supervisor',5);
forceConnectByPath(model,'Dynamic Obstacle Motion',3,'Dynamic Safety Supervisor',6);
forceConnectByPath(model,'Dynamic Obstacle Motion',4,'Dynamic Safety Supervisor',7);
forceConnectByPath(model,'Obstacle Radius',1,'Dynamic Safety Supervisor',8);
forceConnectByPath(model,'Robot Radius',1,'Dynamic Safety Supervisor',9);
forceConnectByPath(model,'Safe Distance',1,'Dynamic Safety Supervisor',10);
forceConnectByPath(model,'Omega Max',1,'Dynamic Safety Supervisor',11);
forceConnectByPath(model,'Prediction Horizon',1,'Dynamic Safety Supervisor',12);
forceConnectByPath(model,'Prediction Step',1,'Dynamic Safety Supervisor',13);
forceConnectByPath(model,'Robot Target Speed',1,'Dynamic Safety Supervisor',14);
forceConnectByPath(model,'Planning Buffer',1,'Dynamic Safety Supervisor',15);
% Exact future obstacle positions use the same simulation clock and reverse-path geometry.
forceConnectByPath(model,'Obstacle Clock',1,'Dynamic Safety Supervisor',16);
forceConnectByPath(model,'X Reference',1,'Dynamic Safety Supervisor',17);
forceConnectByPath(model,'Y Reference',1,'Dynamic Safety Supervisor',18);
forceConnectByPath(model,'Reference Arc Length',1,'Dynamic Safety Supervisor',19);
forceConnectByPath(model,'Obstacle Speed',1,'Dynamic Safety Supervisor',20);
forceConnectByPath(model,'Static Obstacle X',1,'Dynamic Safety Supervisor',21);
forceConnectByPath(model,'Static Obstacle Y',1,'Dynamic Safety Supervisor',22);

% Log safety output signals.
forceConnectByPath(model,'Dynamic Safety Supervisor',3,'Predicted Separation Log',1);
forceConnectByPath(model,'Dynamic Safety Supervisor',4,'Avoidance Mode Log',1);
forceConnectByPath(model,'Dynamic Safety Supervisor',1,'Safe Velocity Log',1);
forceConnectByPath(model,'Dynamic Safety Supervisor',2,'Safe Omega Log',1);

% Recompile after all connections.
set_param(model,'SimulationCommand','update');

end


%% ==============================================================
% LOCAL FUNCTION: ENSURE A BLOCK EXISTS
% ==============================================================

function ensureBlock(model,libraryPath,name,position)

path = [model '/' name];
if isempty(find_system(model,'SearchDepth',1,'Name',name))
    add_block(libraryPath,path,'Position',position);
end

end


%% ==============================================================
% LOCAL FUNCTION: ENSURE MATLAB FUNCTION BLOCK
% ==============================================================

function ensureMatlabFunctionBlock(model,name,position,script,inputSizes,outputSizes)

path = [model '/' name];

if isempty(find_system(model,'SearchDepth',1,'Name',name))
    add_block('simulink/User-Defined Functions/MATLAB Function', ...
        path,'Position',position);
end

bd = get_param(model,'Object');
chart = find(bd,'-isa','Stateflow.EMChart','Path',path);

if numel(chart) ~= 1
    error('Could not locate MATLAB Function chart: %s',path);
end

chart.Script = script;

if numel(chart.Inputs) ~= numel(inputSizes)
    error('Unexpected input count for MATLAB Function block "%s".',name);
end
if numel(chart.Outputs) ~= numel(outputSizes)
    error('Unexpected output count for MATLAB Function block "%s".',name);
end

for k = 1:numel(inputSizes)
    chart.Inputs(k).Props.Array.Size = inputSizes{k};
end
for k = 1:numel(outputSizes)
    chart.Outputs(k).Props.Array.Size = outputSizes{k};
end

end


%% ==============================================================
% LOCAL FUNCTION: ENSURE TO-WORKSPACE LOG
% ==============================================================

function ensureWorkspaceBlock(model,name,variableName,position)

path = [model '/' name];

if isempty(find_system(model,'SearchDepth',1,'Name',name))
    add_block('simulink/Sinks/To Workspace',path, ...
        'VariableName',variableName, ...
        'SaveFormat','Timeseries', ...
        'Position',position);
else
    set_param(path,'VariableName',variableName,'SaveFormat','Timeseries');
end

end


%% ==============================================================
% LOCAL FUNCTION: FORCE BLOCK-TO-BLOCK CONNECTION
% ==============================================================

function forceConnectByPath(model,srcBlock,srcPort,dstBlock,dstPort)

srcPath = [model '/' srcBlock];
dstPath = [model '/' dstBlock];

srcPH = get_param(srcPath,'PortHandles');
dstPH = get_param(dstPath,'PortHandles');

if srcPort > numel(srcPH.Outport)
    error('Source port %d does not exist on %s.',srcPort,srcPath);
end
if dstPort > numel(dstPH.Inport)
    error('Destination port %d does not exist on %s.',dstPort,dstPath);
end

oldLine = get_param(dstPH.Inport(dstPort),'Line');
if ~isempty(oldLine) && all(oldLine ~= -1)
    delete_line(oldLine);
end

add_line(model, ...
    [srcBlock '/' num2str(srcPort)], ...
    [dstBlock '/' num2str(dstPort)], ...
    'autorouting','on');

end


%% ==============================================================
% LOCAL FUNCTION: CONTINUOUS CLOSEST APPROACH BETWEEN SAMPLES
% ==============================================================

function minDistance = minimumContinuousCenterDistance(x,y,xObs,yObs)

n = min([numel(x),numel(y),numel(xObs),numel(yObs)]);
if n < 1
    minDistance = inf;
    return;
end
relX = xObs(1:n)-x(1:n);
relY = yObs(1:n)-y(1:n);
minDistance = min(hypot(relX,relY));
for k = 1:n-1
    stepX = relX(k+1)-relX(k);
    stepY = relY(k+1)-relY(k);
    denominator = stepX*stepX+stepY*stepY;
    if denominator > 1e-12
        alpha = -(relX(k)*stepX+relY(k)*stepY)/denominator;
        alpha = min(max(alpha,0),1);
        d = hypot(relX(k)+alpha*stepX,relY(k)+alpha*stepY);
        if d < minDistance
            minDistance = d;
        end
    end
end
end


%% ==============================================================
% LOCAL FUNCTION: SCENARIO TOKEN
% ==============================================================

function token = scenarioToken(label)

token = lower(label);
token = strrep(token,' ','_');
token = strrep(token,'-','_');
token = strrep(token,'/','_');

end
